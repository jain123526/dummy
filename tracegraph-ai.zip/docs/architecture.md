# TraceGraph AI — System Architecture (Persistent Database-Backed Engine)

## 1. Overview
TraceGraph AI is an enterprise microservice observability and Root Cause Analysis (RCA) platform. It pairs live OpenTelemetry (OTel) metrics and distributed traces with a Spatial-Temporal Graph Neural Network (ST-GNN) to detect cascading degradations and isolate physical root causes.

### Zero-Waste Retention Strategy
Rather than indiscriminately persisting millions of nominal microservice traces (which creates enormous storage costs and database bloat), TraceGraph AI uses an online **Zero-Waste Retention Architecture**:
- Nominal traces and nominal metrics are evaluated against a **dynamic anomaly threshold $\tau$**.
- Traces whose reconstruction MSE or anomaly score $< \tau$ are immediately **pruned in real time**, saving **90%+ of storage costs**.
- Real-time rolling baseline distributions ($\mu_{\text{baseline}}$ and $\sigma_{\text{baseline}}$) are updated continuously in the `baseline_stats` table using Welford's algorithm without retaining raw nominal traces.
- **Only anomalous traces, degraded spans, GNN continuous edge masks, and Root Cause Analysis reports are permanently persisted** into `anomalous_microservices` and `anomalous_spans`.

```mermaid
graph TD
    A[Client Traffic / Microservices] -->|OTLP Traces & Spans| B[TraceGraph Ingestion Engine]
    B --> C[Dynamic Topology Builder & Feature Tensor X]
    C --> D[Spatial-Temporal GNN & Autoencoder]
    D --> E{Score >= Dynamic Threshold Tau?}
    E -->|No: Nominal| F[Zero-Waste Pruning: Prune Immediately]
    F --> G[Update baseline_stats: mu and sigma]
    E -->|Yes: Anomalous| H[Trip Anomaly Alert & Run GNNExplainer]
    H --> I[Evidence-Based RCA Engine]
    I --> J[INSERT INTO anomalous_microservices]
    I --> K[INSERT INTO anomalous_spans]
    J --> L[Gemini Incident Remediation Playbook]
    J --> M[Interactive Operator Topology UI]
```

## 2. Database Schema Design

### 2.1 `services` Table
Stores registered microservices in the cluster topology:
- `id` (VARCHAR / TEXT, PK): Unique service ID (e.g., `db-cluster`, `payment-service`)
- `name` (VARCHAR): Human-readable service name
- `tier` (VARCHAR): Architectural tier (`edge`, `core`, `business`, `data`, `cache`, `messaging`, `external`)
- `host` (VARCHAR): Kubernetes pod DNS or host
- `version` (VARCHAR): Deployment release version
- `created_at` (TIMESTAMP): Registration time

### 2.2 `baseline_stats` Table (Dynamic Threshold Computation)
Maintains historical nominal parameter distributions without raw trace bloat:
- `service_id` (VARCHAR, FK &rarr; `services.id`): Service identifier or `cluster-wide`
- `metric_name` (VARCHAR): Metric key (`reconstruction_mse`, `latency_ms`, `error_rate`)
- `mean_val` ($\mu_0$, FLOAT): Baseline rolling mean
- `std_val` ($\sigma_0$, FLOAT): Baseline rolling standard deviation
- `sample_count` (INTEGER): Total nominal sample observations
- `updated_at` (TIMESTAMP): Timestamp of last baseline update

### 2.3 `anomalous_microservices` Table (Zero-Waste Reduction)
Retains only true abnormal incidents and explainability artifacts:
- `id` (VARCHAR / UUID, PK): Unique record identifier
- `incident_id` (VARCHAR): Incident tracking key
- `timestamp` (BIGINT / TIMESTAMP): Onset time in unix milliseconds
- `root_cause_service_id` (VARCHAR, FK &rarr; `services.id`): Isolated culprit node
- `symptom_service_id` (VARCHAR, FK &rarr; `services.id`): First degraded caller node
- `anomaly_score` ($\tau_i$, FLOAT): Highest GNN anomaly likelihood
- `threshold_tau` ($\tau$, FLOAT): Dynamic threshold $\tau$ active during incident
- `reconstruction_error` (FLOAT): Autoencoder reconstruction loss $L_{\text{trace}}$
- `propagation_path` (JSONB / TEXT): Ordered cascade sequence $[c_{\text{root}}, \dots, s_{\text{symptom}}]$
- `gnn_edge_attributions` (JSONB): Continuous edge mask importances $M_e$
- `gnn_feature_attributions` (JSONB): Continuous feature mask importances $M_f$
- `evidence_log` (JSONB): Multi-factor empirical causal evidence log
- `resolved` (BOOLEAN): Status flag

### 2.4 `anomalous_spans` Table
Stores distributed trace spans belonging strictly to anomalous executions:
- `span_id` (VARCHAR, PK): OpenTelemetry span identifier
- `trace_id` (VARCHAR): Distributed trace ID
- `incident_id` (VARCHAR, FK &rarr; `anomalous_microservices.incident_id`)
- `service_name` (VARCHAR): Name of the executing service
- `operation_name` (VARCHAR): Endpoint or RPC method
- `duration_ms` (FLOAT): Latency in milliseconds
- `status_code` (INTEGER): HTTP / gRPC status code
- `error_message` (TEXT): Failure or timeout details
- `attributes` (JSONB): Span tags and attributes

## 3. Mathematical Dynamic Threshold ($\tau$)
$$\tau = \mu_{\text{baseline}} + k \cdot \sigma_{\text{baseline}}$$
Where:
- $\mu_{\text{baseline}}$ is expected nominal mean reconstruction loss / anomaly probability.
- $\sigma_{\text{baseline}}$ is standard deviation across nominal windows.
- $k$ is a scaling factor (default $k = 3.0$).
