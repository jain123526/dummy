export type ServiceTier = 'edge' | 'core' | 'business' | 'data' | 'cache' | 'messaging' | 'external';
export type FaultType = 'latency_spike' | 'error_cascade' | 'resource_exhaustion' | 'network_partition';
export type TelemetryMode = 'live' | 'simulation';
export type ModelStatus = 'trained' | 'untrained' | 'training';

export interface ServiceMetrics {
  latencyMs: number;
  errorRate: number; // 0.0 to 1.0
  requestRate: number; // requests / sec
  cpuPct: number; // 0 to 100
  memPct: number; // 0 to 100
}

export interface MetricHistoryPoint extends ServiceMetrics {
  timestamp: number;
  tick: number;
}

export interface ServiceNode {
  id: string;
  name: string;
  tier: ServiceTier;
  host: string;
  version: string;
  status: 'nominal' | 'degraded' | 'critical';
  currentMetrics: ServiceMetrics;
  history: MetricHistoryPoint[]; // Last T points
  normalizedFeatures?: number[][]; // [T, 5] normalized tensor
  anomalyScore: number; // 0.0 to 1.0
  isRootCause?: boolean;
  isInCascadePath?: boolean;
  temporalOnsetTime?: number; // Detected timestamp when anomaly started
}

export interface EdgeDependency {
  id: string;
  source: string; // Caller
  target: string; // Callee
  callType: 'grpc' | 'http' | 'async' | 'db_conn';
  rps: number;
  meanLatency: number;
  errorRate: number;
  attributionWeight?: number; // GNNExplainer edge importance [0, 1]
  isCausalPath?: boolean;
  isAnomalous?: boolean;
  lastObservedTraceId?: string;
}

export interface Span {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  serviceName: string;
  operationName: string;
  startTimeOffsetMs: number;
  durationMs: number;
  statusCode: number; // 200, 500, 504, etc.
  error?: string;
  attributes: Record<string, string | number | boolean>;
}

export interface TraceRecord {
  traceId: string;
  rootService: string;
  operation: string;
  startTime: number;
  totalDurationMs: number;
  status: 'ok' | 'error';
  spans: Span[];
}

export interface ActiveFault {
  faultId: string;
  faultType: FaultType;
  targetService: string;
  durationTicks: number;
  remainingTicks: number;
  magnitude: number;
  createdAt: number;
  description: string;
  isRealEnv?: boolean;
}

export interface EdgeAttribution {
  source: string;
  target: string;
  importance: number; // 0.0 to 1.0
  latencyMs: number;
  errorRate: number;
}

export interface FeatureAttribution {
  featureName: string;
  importance: number; // 0.0 to 1.0
  baselineVal: number;
  currentVal: number;
}

export interface RCAEvidence {
  type: 'temporal_onset' | 'trace_dependency' | 'edge_latency' | 'feature_attribution' | 'metric_threshold';
  description: string;
  confidenceContribution: number;
}

export interface RCAReport {
  incidentId: string;
  timestamp: number;
  targetNode: string; // Node where symptom was first detected
  rootCauseCandidate: string; // Physical root cause pinpointed by GNNExplainer + temporal precedence
  rootCauseConfidence: number; // [0, 1]
  propagationPath: string[]; // Order of cascade: [root, ..., target]
  edgeAttributions: EdgeAttribution[];
  featureAttributions: FeatureAttribution[];
  nodeAttributions: Record<string, number>;
  evidenceList: RCAEvidence[];
  explanationSummary: string;
  aiMitigationPlaybook?: string;
}

export interface IncidentRecord {
  id: string;
  timestamp: number;
  targetNode: string;
  rootCauseNode: string;
  anomalyScore: number;
  faultType: FaultType;
  propagationPath: string[];
  resolved: boolean;
  summary: string;
  details: RCAReport;
}

export interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
  auroc: number;
  falsePositiveRate: number;
  rcaTop1: number;
  rcaTop3: number;
  meanInferenceLatencyMs: number;
  trainLoss: number[];
  valLoss: number[];
  epochCount: number;
  trainedAt: string;
  trainingSamples: number;
  testSamples: number;
}

export interface DynamicThresholdStats {
  tau: number;
  mu: number;
  sigma: number;
  k: number;
  sampleCount: number;
  storageSavedPct: number;
  nominalPrunedCount: number;
  anomalousPersistedCount: number;
}

export interface TelemetrySnapshot {
  tick: number;
  timestamp: number;
  mode: TelemetryMode;
  modelStatus: ModelStatus;
  windowSize: number;
  nodes: ServiceNode[];
  edges: EdgeDependency[];
  traces: TraceRecord[];
  activeFaults: ActiveFault[];
  anomalyDetected: boolean;
  anomalousNodes: string[];
  currentRCA: RCAReport | null;
  modelMetrics?: ModelMetrics;
  dynamicThreshold?: DynamicThresholdStats;
  incidents?: IncidentRecord[];
  ingestionStats?: {
    tracesPerSec: number;
    metricsPerSec: number;
    lastIngestedAt: number;
  };
}

export function createInitialSnapshot(): TelemetrySnapshot {
  return {
    tick: 0,
    timestamp: Date.now(),
    mode: 'simulation',
    modelStatus: 'trained',
    windowSize: 20,
    nodes: [],
    edges: [],
    traces: [],
    activeFaults: [],
    anomalyDetected: false,
    anomalousNodes: [],
    currentRCA: null,
    incidents: [],
    dynamicThreshold: {
      tau: 0.35,
      mu: 0.185,
      sigma: 0.048,
      k: 3.0,
      sampleCount: 100,
      storageSavedPct: 95.8,
      nominalPrunedCount: 120,
      anomalousPersistedCount: 0,
    },
  };
}
