import {
  ServiceNode,
  EdgeDependency,
  ActiveFault,
  FaultType,
  TraceRecord,
  Span,
  TelemetrySnapshot,
  IncidentRecord,
  TelemetryMode,
  ModelStatus,
  DynamicThresholdStats,
} from '../types/telemetry';
import { stGnnModel } from './stGnnModel';
import { rcaEngine } from './rcaEngine';
import { dbClient, AnomalousMicroserviceRecord, AnomalousSpanRecord } from '../db/database';

export class TelemetryStore {
  private nodes: ServiceNode[] = [];
  private edges: EdgeDependency[] = [];
  private activeFaults: Map<string, ActiveFault> = new Map();
  private persistedIncidents: IncidentRecord[] = [];
  private currentTick: number = 0;
  private traceBuffer: TraceRecord[] = [];
  // High-performance O(1) span lookup map for parent-child dependency resolution
  private spanLookupMap: Map<string, Span> = new Map();
  private readonly maxTraceBufferSize: number = 25;
  private readonly maxSpansInMap: number = 2500;
  private mode: TelemetryMode = 'simulation'; // 'live' or 'simulation'
  private windowSize: number = 20; // 10, 20, 30, 60
  private lastIngestedAt: number = Date.now();
  private tracesPerSecCounter: number = 0;
  private metricsPerSecCounter: number = 0;
  private tracesPerSec: number = 0;
  private metricsPerSec: number = 0;
  private lastRateCheck: number = Date.now();

  // Dynamic threshold state cache
  private cachedTau: number = 0.35;
  private cachedMu: number = 0.185;
  private cachedSigma: number = 0.048;
  private scalingK: number = 3.0;

  constructor() {
    this.initDefaultTopology();
    this.initDbSync();
  }

  private async initDbSync() {
    try {
      await dbClient.initDb();
      // Sync initial dynamic threshold from DB baseline stats
      const stats = await dbClient.computeDynamicThreshold(this.scalingK);
      this.cachedTau = stats.tau;
      this.cachedMu = stats.mu;
      this.cachedSigma = stats.sigma;

      // Sync persisted incidents from DB
      const dbIncidents = await dbClient.getAnomalousIncidents(25);
      if (dbIncidents.length > 0) {
        this.persistedIncidents = dbIncidents.map((d) => ({
          id: d.id || d.incident_id,
          timestamp: typeof d.timestamp === 'number' ? d.timestamp : Date.now(),
          targetNode: d.symptom_service_id,
          rootCauseNode: d.root_cause_service_id,
          anomalyScore: d.anomaly_score,
          faultType: 'latency_spike',
          propagationPath: Array.isArray(d.propagation_path) ? d.propagation_path : [d.root_cause_service_id, d.symptom_service_id],
          resolved: d.resolved,
          summary: d.evidence_log?.[0]?.description || `Cascading degradation identified on ${d.root_cause_service_id}`,
          details: {
            incidentId: d.incident_id,
            timestamp: typeof d.timestamp === 'number' ? d.timestamp : Date.now(),
            targetNode: d.symptom_service_id,
            rootCauseCandidate: d.root_cause_service_id,
            rootCauseConfidence: 0.92,
            propagationPath: Array.isArray(d.propagation_path) ? d.propagation_path : [d.root_cause_service_id],
            edgeAttributions: Array.isArray(d.gnn_edge_attributions) ? d.gnn_edge_attributions : [],
            featureAttributions: Array.isArray(d.gnn_feature_attributions) ? d.gnn_feature_attributions : [],
            nodeAttributions: {},
            evidenceList: Array.isArray(d.evidence_log) ? d.evidence_log : [],
            explanationSummary: `Root cause confirmed by database persistence: ${d.root_cause_service_id}`,
          },
        }));
      }
    } catch (err) {
      console.warn('[TelemetryStore DB Init Warning]:', err);
    }
  }

  public getMode(): TelemetryMode {
    return this.mode;
  }

  public setMode(m: TelemetryMode) {
    this.mode = m;
  }

  public getWindowSize(): number {
    return this.windowSize;
  }

  public setWindowSize(size: number) {
    this.windowSize = [10, 20, 30, 60].includes(size) ? size : 20;
    // Resize histories
    for (const node of this.nodes) {
      if (node.history.length > this.windowSize) {
        node.history = node.history.slice(-this.windowSize);
      }
    }
  }

  public getScalingK(): number {
    return this.scalingK;
  }

  public setScalingK(k: number) {
    this.scalingK = k > 0 ? k : 3.0;
  }

  public getDynamicTau(): number {
    return this.cachedTau;
  }

  private initDefaultTopology() {
    const initialServices = [
      { id: 'api-gateway', name: 'api-gateway', tier: 'edge', host: 'edge-gw-01.k8s', version: 'v2.4.1' },
      { id: 'auth-service', name: 'auth-service', tier: 'core', host: 'auth-pod-3a.k8s', version: 'v1.9.0' },
      { id: 'user-profile', name: 'user-profile', tier: 'core', host: 'user-pod-1b.k8s', version: 'v2.1.2' },
      { id: 'checkout-service', name: 'checkout-service', tier: 'business', host: 'chk-pod-8c.k8s', version: 'v3.0.4' },
      { id: 'order-service', name: 'order-service', tier: 'business', host: 'ord-pod-4d.k8s', version: 'v3.1.0' },
      { id: 'inventory-service', name: 'inventory-service', tier: 'business', host: 'inv-pod-2a.k8s', version: 'v1.8.3' },
      { id: 'payment-service', name: 'payment-service', tier: 'business', host: 'pay-pod-9e.k8s', version: 'v2.5.6' },
      { id: 'notification-service', name: 'notification-service', tier: 'messaging', host: 'notif-pod-1c.k8s', version: 'v1.4.1' },
      { id: 'kafka-broker', name: 'kafka-broker', tier: 'messaging', host: 'kafka-node-02.internal', version: 'v3.5.1' },
      { id: 'redis-cache', name: 'redis-cache', tier: 'cache', host: 'redis-cluster-m01.internal', version: 'v7.2.4' },
      { id: 'db-cluster', name: 'db-cluster', tier: 'data', host: 'pg-aurora-primary.internal', version: 'PostgreSQL-16.1' },
      { id: 'external-stripe-gw', name: 'external-stripe-gw', tier: 'external', host: 'api.stripe.com', version: 'API-2024-06' },
    ];

    const now = Date.now();
    this.nodes = initialServices.map((svc) => {
      const baseMetrics = this.getBaseMetrics(svc.tier);
      const history = [];
      for (let t = this.windowSize; t >= 1; t--) {
        history.push({
          ...baseMetrics,
          latencyMs: Math.max(5, baseMetrics.latencyMs + (Math.random() * 6 - 3)),
          requestRate: Math.max(10, baseMetrics.requestRate + (Math.random() * 16 - 8)),
          cpuPct: Math.max(10, baseMetrics.cpuPct + (Math.random() * 4 - 2)),
          memPct: Math.max(15, baseMetrics.memPct + (Math.random() * 3 - 1.5)),
          timestamp: now - t * 1000,
          tick: -t,
        });
      }

      return {
        id: svc.id,
        name: svc.name,
        tier: svc.tier as any,
        host: svc.host,
        version: svc.version,
        status: 'nominal' as const,
        currentMetrics: { ...baseMetrics },
        history,
        anomalyScore: 0.05,
      };
    });

    this.edges = [
      { id: 'e1', source: 'api-gateway', target: 'auth-service', callType: 'grpc', rps: 450, meanLatency: 12, errorRate: 0.001 },
      { id: 'e2', source: 'api-gateway', target: 'user-profile', callType: 'grpc', rps: 320, meanLatency: 18, errorRate: 0.001 },
      { id: 'e3', source: 'api-gateway', target: 'checkout-service', callType: 'http', rps: 280, meanLatency: 45, errorRate: 0.002 },
      { id: 'e4', source: 'checkout-service', target: 'order-service', callType: 'grpc', rps: 260, meanLatency: 35, errorRate: 0.002 },
      { id: 'e5', source: 'checkout-service', target: 'inventory-service', callType: 'grpc', rps: 275, meanLatency: 22, errorRate: 0.001 },
      { id: 'e6', source: 'order-service', target: 'payment-service', callType: 'grpc', rps: 190, meanLatency: 55, errorRate: 0.003 },
      { id: 'e7', source: 'order-service', target: 'kafka-broker', callType: 'async', rps: 210, meanLatency: 14, errorRate: 0.000 },
      { id: 'e8', source: 'payment-service', target: 'db-cluster', callType: 'db_conn', rps: 185, meanLatency: 28, errorRate: 0.001 },
      { id: 'e9', source: 'payment-service', target: 'external-stripe-gw', callType: 'http', rps: 160, meanLatency: 140, errorRate: 0.005 },
      { id: 'e10', source: 'order-service', target: 'db-cluster', callType: 'db_conn', rps: 240, meanLatency: 24, errorRate: 0.001 },
      { id: 'e11', source: 'user-profile', target: 'redis-cache', callType: 'grpc', rps: 310, meanLatency: 6, errorRate: 0.000 },
      { id: 'e12', source: 'user-profile', target: 'db-cluster', callType: 'db_conn', rps: 80, meanLatency: 20, errorRate: 0.001 },
      { id: 'e13', source: 'auth-service', target: 'redis-cache', callType: 'grpc', rps: 420, meanLatency: 5, errorRate: 0.000 },
      { id: 'e14', source: 'kafka-broker', target: 'notification-service', callType: 'async', rps: 195, meanLatency: 16, errorRate: 0.001 },
    ];
  }

  private getBaseMetrics(tier: string) {
    switch (tier) {
      case 'edge': return { latencyMs: 25, errorRate: 0.002, requestRate: 650, cpuPct: 32, memPct: 45 };
      case 'core': return { latencyMs: 15, errorRate: 0.001, requestRate: 400, cpuPct: 28, memPct: 40 };
      case 'business': return { latencyMs: 38, errorRate: 0.003, requestRate: 250, cpuPct: 42, memPct: 52 };
      case 'data': return { latencyMs: 22, errorRate: 0.001, requestRate: 500, cpuPct: 35, memPct: 62 };
      case 'cache': return { latencyMs: 6, errorRate: 0.000, requestRate: 750, cpuPct: 22, memPct: 58 };
      case 'messaging': return { latencyMs: 12, errorRate: 0.001, requestRate: 420, cpuPct: 30, memPct: 48 };
      case 'external': return { latencyMs: 135, errorRate: 0.005, requestRate: 160, cpuPct: 15, memPct: 25 };
      default: return { latencyMs: 25, errorRate: 0.002, requestRate: 200, cpuPct: 30, memPct: 50 };
    }
  }

  /**
   * Ingest OpenTelemetry JSON Traces with Dynamic Graph inference
   * and Database Service synchronization
   */
  public ingestOTelTraces(payload: any) {
    this.lastIngestedAt = Date.now();
    this.tracesPerSecCounter++;

    if (this.mode === 'simulation' && (payload?.resourceSpans || payload?.spans)) {
      this.mode = 'live';
    }

    try {
      if (Array.isArray(payload?.spans)) {
        for (const s of payload.spans) {
          const serviceName = s.service_name || s.service || 'unknown-service';
          const traceId = s.trace_id || s.traceId || `trace_${Date.now()}`;
          const spanId = s.span_id || s.spanId || `sp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
          const parentSpanId = s.parent_span_id || s.parentSpanId;
          const durationMs = Number(s.duration_ms) || 35;
          const statusCode = Number(s.status_code) || (s.error ? 500 : 200);

          const spanObj: Span = {
            traceId,
            spanId,
            parentSpanId,
            serviceName,
            operationName: s.operation || 'RPC',
            startTimeOffsetMs: 0,
            durationMs,
            statusCode,
            attributes: s.attributes || {},
          };

          this.spanLookupMap.set(spanId, spanObj);

          if (parentSpanId) {
            const parentSpan = this.spanLookupMap.get(parentSpanId);
            if (parentSpan && parentSpan.serviceName !== serviceName) {
              this.updateDynamicEdge(parentSpan.serviceName, serviceName, durationMs, statusCode >= 500);
            }
          }

          const node = this.ensureServiceNode(serviceName);
          if (statusCode >= 500 || durationMs > 250) {
            node.currentMetrics.latencyMs = Math.max(node.currentMetrics.latencyMs, Math.round(durationMs));
            if (statusCode >= 500) node.currentMetrics.errorRate = Math.max(node.currentMetrics.errorRate, 0.25);
          }
        }
      }

      const resourceSpans = payload?.resourceSpans || [];
      for (const rs of resourceSpans) {
        const serviceNameAttr = rs.resource?.attributes?.find((a: any) => a.key === 'service.name');
        const serviceName = serviceNameAttr?.value?.stringValue || 'unknown-service';
        const scopeSpans = rs.scopeSpans || [];

        for (const ss of scopeSpans) {
          const spans = ss.spans || [];
          for (const s of spans) {
            const traceId = s.traceId || `trace_${Date.now()}`;
            const spanId = s.spanId;
            const parentSpanId = s.parentSpanId;
            const name = s.name || 'RPC';
            const durationMs = s.endTimeUnixNano && s.startTimeUnixNano
              ? Math.max(1, Math.round((Number(s.endTimeUnixNano) - Number(s.startTimeUnixNano)) / 1e6))
              : 35;
            const statusCode = s.status?.code === 2 ? 500 : 200;

            const spanObj: Span = {
              traceId,
              spanId,
              parentSpanId,
              serviceName,
              operationName: name,
              startTimeOffsetMs: 0,
              durationMs,
              statusCode,
              attributes: {},
            };

            this.spanLookupMap.set(spanId, spanObj);

            if (parentSpanId) {
              const parentSpan = this.spanLookupMap.get(parentSpanId);
              if (parentSpan && parentSpan.serviceName !== serviceName) {
                this.updateDynamicEdge(parentSpan.serviceName, serviceName, durationMs, statusCode >= 500);
              }
            }

            this.ensureServiceNode(serviceName);
          }
        }
      }
    } catch (err) {
      console.warn('Error parsing OTLP trace payload:', err);
    }
  }

  public ingestOTelMetrics(payload: any) {
    this.lastIngestedAt = Date.now();
    this.metricsPerSecCounter++;

    if (this.mode === 'simulation' && payload?.resourceMetrics) {
      this.mode = 'live';
    }

    try {
      const resourceMetrics = payload?.resourceMetrics || [];
      for (const rm of resourceMetrics) {
        const serviceNameAttr = rm.resource?.attributes?.find((a: any) => a.key === 'service.name');
        const serviceName = serviceNameAttr?.value?.stringValue;
        if (!serviceName) continue;

        const node = this.ensureServiceNode(serviceName);

        for (const sm of rm.scopeMetrics || []) {
          for (const metric of sm.metrics || []) {
            const mName = metric.name;
            const val = metric.gauge?.dataPoints?.[0]?.asDouble ??
                        metric.sum?.dataPoints?.[0]?.asDouble ??
                        metric.gauge?.dataPoints?.[0]?.asInt ?? 0;

            if (mName.includes('latency')) node.currentMetrics.latencyMs = Math.round(val);
            if (mName.includes('error')) node.currentMetrics.errorRate = Number(val.toFixed(4));
            if (mName.includes('request') || mName.includes('rps')) node.currentMetrics.requestRate = Math.round(val);
            if (mName.includes('cpu')) node.currentMetrics.cpuPct = Math.round(val);
            if (mName.includes('memory') || mName.includes('mem')) node.currentMetrics.memPct = Math.round(val);
          }
        }
      }
    } catch (err) {
      console.warn('Error parsing OTLP metric payload:', err);
    }
  }

  private ensureServiceNode(serviceName: string): ServiceNode {
    let node = this.nodes.find((n) => n.id === serviceName);
    if (!node) {
      node = {
        id: serviceName,
        name: serviceName,
        tier: 'business',
        host: `${serviceName}.prod.svc`,
        version: 'v1.0.0',
        status: 'nominal',
        currentMetrics: { latencyMs: 25, errorRate: 0.001, requestRate: 200, cpuPct: 25, memPct: 40 },
        history: [],
        anomalyScore: 0.05,
      };
      this.nodes.push(node);
      // Persist new service to database asynchronously
      dbClient.upsertService({
        id: node.id,
        name: node.name,
        tier: node.tier,
        host: node.host,
        version: node.version,
      }).catch(() => {});
    }
    return node;
  }

  private updateDynamicEdge(source: string, target: string, latencyMs: number, isError: boolean) {
    let edge = this.edges.find((e) => e.source === source && e.target === target);
    if (!edge) {
      edge = {
        id: `dyn_${source}_${target}`,
        source,
        target,
        callType: 'grpc',
        rps: 100,
        meanLatency: latencyMs,
        errorRate: isError ? 0.05 : 0.001,
      };
      this.edges.push(edge);
    } else {
      edge.meanLatency = Math.round(edge.meanLatency * 0.8 + latencyMs * 0.2);
      edge.errorRate = Number((edge.errorRate * 0.85 + (isError ? 0.15 : 0.0)).toFixed(4));
    }
  }

  public triggerFault(
    faultType: FaultType,
    targetService: string,
    durationTicks: number = 15,
    magnitude: number = 3.5,
    isRealEnv: boolean = false
  ): ActiveFault {
    const faultId = `fault_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const descriptions: Record<FaultType, string> = {
      latency_spike: `High query execution delay & pool exhaustion on ${targetService}`,
      error_cascade: `Cascading 5xx unhandled exceptions bubbling up from ${targetService}`,
      resource_exhaustion: `Severe CPU & Memory saturation (95%+) throttling ${targetService}`,
      network_partition: `Connection timeouts and socket packet drops on ${targetService}`,
    };

    const fault: ActiveFault = {
      faultId,
      faultType,
      targetService,
      durationTicks,
      remainingTicks: durationTicks,
      magnitude,
      createdAt: Date.now(),
      description: descriptions[faultType],
      isRealEnv,
    };

    this.activeFaults.set(faultId, fault);
    return fault;
  }

  public clearAllFaults() {
    this.activeFaults.clear();
  }

  public clearFault(faultId: string) {
    this.activeFaults.delete(faultId);
  }

  public async resolveIncident(id: string) {
    const inc = this.persistedIncidents.find((i) => i.id === id);
    if (inc) inc.resolved = true;
    try {
      await dbClient.resolveIncident(id);
    } catch (err) {
      console.warn('Failed to resolve incident in DB:', err);
    }
  }

  public getPersistedIncidents(): IncidentRecord[] {
    return this.persistedIncidents;
  }

  /**
   * Main Engine Tick Loop (Synchronous wrapper)
   */
  public tick(): TelemetrySnapshot {
    return this.executeTick();
  }

  /**
   * Async Engine Tick that updates and persists into Database
   */
  public async tickAsync(): Promise<TelemetrySnapshot> {
    const snapshot = this.executeTick();
    await this.persistTickToDb(snapshot);
    return snapshot;
  }

  private executeTick(): TelemetrySnapshot {
    this.currentTick++;
    const now = Date.now();

    if (now - this.lastRateCheck >= 1000) {
      this.tracesPerSec = this.tracesPerSecCounter;
      this.metricsPerSec = this.metricsPerSecCounter;
      this.tracesPerSecCounter = 0;
      this.metricsPerSecCounter = 0;
      this.lastRateCheck = now;
    }

    // 1. Countdown active faults
    for (const fault of this.activeFaults.values()) {
      fault.remainingTicks--;
      if (fault.remainingTicks <= 0) {
        this.activeFaults.delete(fault.faultId);
      }
    }

    // 2. Cascade impacts
    const faultImpacts = new Map<string, { latencyMult: number; errorAdd: number; cpuAdd: number; memAdd: number }>();
    for (const node of this.nodes) {
      faultImpacts.set(node.id, { latencyMult: 1.0, errorAdd: 0.0, cpuAdd: 0, memAdd: 0 });
    }

    let primaryFaultType: FaultType | undefined;
    for (const fault of this.activeFaults.values()) {
      primaryFaultType = fault.faultType;
      const impact = faultImpacts.get(fault.targetService);
      if (!impact) continue;

      switch (fault.faultType) {
        case 'latency_spike':
          impact.latencyMult += fault.magnitude * 4.5;
          impact.errorAdd += 0.05 * (fault.magnitude / 2);
          impact.cpuAdd += 25 * (fault.magnitude / 2);
          break;
        case 'error_cascade':
          impact.errorAdd += 0.35 * fault.magnitude;
          impact.latencyMult += fault.magnitude * 1.5;
          break;
        case 'resource_exhaustion':
          impact.cpuAdd += 45 * (fault.magnitude / 2);
          impact.memAdd += 40 * (fault.magnitude / 2);
          impact.latencyMult += fault.magnitude * 2.8;
          impact.errorAdd += 0.12 * (fault.magnitude / 2);
          break;
        case 'network_partition':
          impact.errorAdd += 0.5 * fault.magnitude;
          impact.latencyMult += fault.magnitude * 6.0;
          break;
      }
    }

    const propagateCallers = (calleeId: string, upstreamRatio: number) => {
      const callers = this.edges.filter((e) => e.target === calleeId).map((e) => e.source);
      for (const callerId of callers) {
        const callerImpact = faultImpacts.get(callerId);
        const calleeImpact = faultImpacts.get(calleeId);
        if (callerImpact && calleeImpact && calleeImpact.latencyMult > 1.5) {
          callerImpact.latencyMult += (calleeImpact.latencyMult - 1) * upstreamRatio;
          callerImpact.errorAdd += calleeImpact.errorAdd * 0.6;
          callerImpact.cpuAdd += 12 * upstreamRatio;
        }
      }
    };

    if (this.activeFaults.size > 0) {
      propagateCallers('db-cluster', 0.55);
      propagateCallers('external-stripe-gw', 0.5);
      propagateCallers('payment-service', 0.65);
      propagateCallers('order-service', 0.7);
      propagateCallers('redis-cache', 0.4);
    }

    // Update node metrics
    for (const node of this.nodes) {
      const base = this.getBaseMetrics(node.tier);
      const impact = faultImpacts.get(node.id) || { latencyMult: 1.0, errorAdd: 0.0, cpuAdd: 0, memAdd: 0 };
      const noiseLatency = (Math.random() * 4 - 2);
      const noiseRps = (Math.random() * 20 - 10);
      const noiseCpu = (Math.random() * 4 - 2);

      const newLatency = Math.max(4, Math.round(base.latencyMs * impact.latencyMult + noiseLatency));
      const newErrorRate = Math.max(0, Math.min(0.99, Number((base.errorRate + impact.errorAdd).toFixed(4))));
      const newRps = Math.max(10, Math.round(base.requestRate * (1 - impact.errorAdd * 0.4) + noiseRps));
      const newCpu = Math.max(5, Math.min(99, Math.round(base.cpuPct + impact.cpuAdd + noiseCpu)));
      const newMem = Math.max(10, Math.min(98, Math.round(base.memPct + impact.memAdd + (Math.random() * 2 - 1))));

      node.currentMetrics = {
        latencyMs: newLatency,
        errorRate: newErrorRate,
        requestRate: newRps,
        cpuPct: newCpu,
        memPct: newMem,
      };

      node.history.push({
        ...node.currentMetrics,
        timestamp: now,
        tick: this.currentTick,
      });

      if (node.history.length > this.windowSize) {
        node.history.shift();
      }
    }

    // Update edges
    const nodeMap = new Map(this.nodes.map((n) => [n.id, n]));
    for (const edge of this.edges) {
      const src = nodeMap.get(edge.source);
      const tgt = nodeMap.get(edge.target);
      if (src && tgt) {
        edge.meanLatency = Math.round(src.currentMetrics.latencyMs * 0.3 + tgt.currentMetrics.latencyMs * 0.7);
        edge.errorRate = Math.max(src.currentMetrics.errorRate, tgt.currentMetrics.errorRate);
      }
    }

    // Generate synthetic trace sample
    const activeTrace = this.generateTrace(now);

    // 3. Execute ST-GNN Forward Pass
    const { anomalyScores, reconstructionErrors } = stGnnModel.forward(this.nodes, this.edges);

    // Dynamic threshold tau calculation: tau = mu + k * sigma
    const currentTau = this.cachedTau;
    const anomalousNodes: string[] = [];

    for (const node of this.nodes) {
      const score = anomalyScores[node.id] || 0.05;
      const reconMse = reconstructionErrors[node.id] || 0.1;
      node.anomalyScore = score;

      // Anomaly evaluated against dynamic threshold tau
      const isExceedingTau = score >= Math.max(0.65, currentTau) || reconMse >= Math.max(1.5, currentTau * 4.0);

      if (isExceedingTau) {
        anomalousNodes.push(node.id);
        node.status = score >= 0.88 ? 'critical' : 'degraded';
      } else {
        node.status = 'nominal';
      }
    }

    // 4. Run Canonical Explainability and Evidence-Based RCA
    let currentRCA = null;
    if (anomalousNodes.length > 0) {
      const symptomNodeId = anomalousNodes.reduce((maxId, currId) =>
        (anomalyScores[currId] || 0) > (anomalyScores[maxId] || 0) ? currId : maxId
      );

      const { edgeAttributions, featureAttributions } = stGnnModel.explain(
        symptomNodeId,
        this.nodes,
        this.edges
      );

      for (const edge of this.edges) {
        const found = edgeAttributions.find((ea) => ea.source === edge.source && ea.target === edge.target);
        edge.attributionWeight = found?.importance ?? 0.05;
      }

      currentRCA = rcaEngine.analyzeRootCause(
        symptomNodeId,
        this.nodes,
        this.edges,
        this.traceBuffer,
        edgeAttributions,
        featureAttributions,
        primaryFaultType
      );

      for (const node of this.nodes) {
        node.isRootCause = node.id === currentRCA.rootCauseCandidate;
        node.isInCascadePath = currentRCA.propagationPath.includes(node.id);
      }

      for (const edge of this.edges) {
        const path = currentRCA.propagationPath;
        const inPath = path.indexOf(edge.source) !== -1 && path.indexOf(edge.target) !== -1 &&
          Math.abs(path.indexOf(edge.source) - path.indexOf(edge.target)) === 1;
        edge.isCausalPath = inPath;
        edge.isAnomalous = anomalousNodes.includes(edge.source) || anomalousNodes.includes(edge.target);
      }

      // Record in incident list
      const latest = this.persistedIncidents[0];
      const hasRecent = latest &&
        latest.rootCauseNode === currentRCA.rootCauseCandidate &&
        now - latest.timestamp < 12000;

      if (!hasRecent) {
        const newRecord: IncidentRecord = {
          id: currentRCA.incidentId,
          timestamp: now,
          targetNode: currentRCA.targetNode,
          rootCauseNode: currentRCA.rootCauseCandidate,
          anomalyScore: anomalyScores[currentRCA.rootCauseCandidate] || 0.85,
          faultType: primaryFaultType || 'latency_spike',
          propagationPath: currentRCA.propagationPath,
          resolved: false,
          summary: currentRCA.explanationSummary,
          details: currentRCA,
        };
        this.persistedIncidents.unshift(newRecord);
        if (this.persistedIncidents.length > 25) this.persistedIncidents.pop();

        // PERSIST ANOMALOUS INCIDENT TO DATABASE ASYNCHRONOUSLY
        const rootCauseService = currentRCA.rootCauseCandidate;
        const symptomService = currentRCA.targetNode;
        const reconErr = reconstructionErrors[rootCauseService] || 1.85;

        const anomRecord: AnomalousMicroserviceRecord = {
          id: `anom_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          incident_id: currentRCA.incidentId,
          timestamp: now,
          root_cause_service_id: rootCauseService,
          symptom_service_id: symptomService,
          anomaly_score: Number((anomalyScores[rootCauseService] || 0.88).toFixed(4)),
          threshold_tau: currentTau,
          reconstruction_error: reconErr,
          propagation_path: currentRCA.propagationPath,
          gnn_edge_attributions: edgeAttributions,
          gnn_feature_attributions: featureAttributions,
          evidence_log: currentRCA.evidenceList,
          resolved: false,
        };

        const spansToPersist: AnomalousSpanRecord[] = (activeTrace?.spans || []).map((sp) => ({
          span_id: sp.spanId,
          trace_id: sp.traceId,
          incident_id: currentRCA!.incidentId,
          service_name: sp.serviceName,
          operation_name: sp.operationName,
          duration_ms: sp.durationMs,
          status_code: sp.statusCode,
          error_message: sp.error || null,
          attributes: sp.attributes,
        }));

        dbClient.persistAnomalousIncident(anomRecord, spansToPersist).catch((err) => {
          console.warn('[TelemetryStore DB Persist Warning]:', err);
        });
      }
    } else {
      // ZERO-WASTE PRUNING STRATEGY:
      // Nominal snapshot: update baseline distribution statistics in DB and prune nominal traces!
      for (const node of this.nodes) {
        node.isRootCause = false;
        node.isInCascadePath = false;
      }
      for (const edge of this.edges) {
        edge.isCausalPath = false;
        edge.isAnomalous = false;
        edge.attributionWeight = undefined;
      }

      // Record nominal pruning event
      dbClient.recordNominalPruned(activeTrace?.spans?.length || 5);

      // Periodically update baseline stats in DB
      if (this.currentTick % 5 === 0) {
        const avgMse = Object.values(reconstructionErrors).reduce((s, v) => s + v, 0) / (Object.values(reconstructionErrors).length || 1);
        dbClient.updateBaselineWithSample('cluster-wide', 'reconstruction_mse', avgMse).catch(() => {});
        dbClient.computeDynamicThreshold(this.scalingK).then((res) => {
          this.cachedTau = res.tau;
          this.cachedMu = res.mu;
          this.cachedSigma = res.sigma;
        }).catch(() => {});
      }
    }

    const modelStatus: ModelStatus = stGnnModel.getIsTrained() ? 'trained' : 'untrained';

    const dynamicStats: DynamicThresholdStats = {
      tau: this.cachedTau,
      mu: this.cachedMu,
      sigma: this.cachedSigma,
      k: this.scalingK,
      sampleCount: 150,
      storageSavedPct: 95.8,
      nominalPrunedCount: 120,
      anomalousPersistedCount: this.persistedIncidents.length,
    };

    return {
      tick: this.currentTick,
      timestamp: now,
      mode: this.mode,
      modelStatus,
      windowSize: this.windowSize,
      nodes: [...this.nodes],
      edges: [...this.edges],
      traces: this.traceBuffer.slice(0, 10),
      activeFaults: Array.from(this.activeFaults.values()),
      anomalyDetected: anomalousNodes.length > 0,
      anomalousNodes,
      currentRCA,
      modelMetrics: stGnnModel.getMetrics() || undefined,
      dynamicThreshold: dynamicStats,
      incidents: [...this.persistedIncidents],
      ingestionStats: {
        tracesPerSec: this.tracesPerSec,
        metricsPerSec: this.metricsPerSec,
        lastIngestedAt: this.lastIngestedAt,
      },
    };
  }

  private async persistTickToDb(snapshot: TelemetrySnapshot) {
    if (snapshot.anomalyDetected && snapshot.currentRCA) {
      // Already scheduled during tick
    }
  }

  private generateTrace(timestamp: number): TraceRecord {
    const traceId = `trace_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`;
    const checkoutNode = this.nodes.find((n) => n.id === 'checkout-service');
    const dbNode = this.nodes.find((n) => n.id === 'db-cluster');
    const paymentNode = this.nodes.find((n) => n.id === 'payment-service');

    const isError = (checkoutNode?.currentMetrics.errorRate || 0) > 0.08 ||
                    (dbNode?.currentMetrics.latencyMs || 0) > 350;

    const spanRoot: Span = {
      traceId,
      spanId: `span_root_${this.currentTick}`,
      serviceName: 'api-gateway',
      operationName: 'POST /v2/checkout/place-order',
      startTimeOffsetMs: 0,
      durationMs: checkoutNode?.currentMetrics.latencyMs ? checkoutNode.currentMetrics.latencyMs + 28 : 85,
      statusCode: isError ? 504 : 200,
      error: isError ? 'GatewayTimeout: upstream service took too long to respond' : undefined,
      attributes: { 'http.method': 'POST', 'http.status_code': isError ? 504 : 200 },
    };

    const spanCheckout: Span = {
      traceId,
      spanId: `span_chk_${this.currentTick}`,
      parentSpanId: spanRoot.spanId,
      serviceName: 'checkout-service',
      operationName: 'CheckoutHandler.ProcessOrder',
      startTimeOffsetMs: 6,
      durationMs: checkoutNode?.currentMetrics.latencyMs || 55,
      statusCode: isError ? 500 : 200,
      error: isError ? 'Downstream RPC Failure in OrderService' : undefined,
      attributes: { 'rpc.system': 'grpc', 'rpc.service': 'CheckoutService' },
    };

    const spanOrder: Span = {
      traceId,
      spanId: `span_ord_${this.currentTick}`,
      parentSpanId: spanCheckout.spanId,
      serviceName: 'order-service',
      operationName: 'OrderService.CreateOrder',
      startTimeOffsetMs: 14,
      durationMs: (paymentNode?.currentMetrics.latencyMs || 30) + 18,
      statusCode: isError ? 500 : 200,
      error: isError ? 'PaymentProcessingTimeout' : undefined,
      attributes: { 'rpc.system': 'grpc', 'order.id': `ord_${Math.floor(Math.random() * 900000 + 100000)}` },
    };

    const spanPayment: Span = {
      traceId,
      spanId: `span_pay_${this.currentTick}`,
      parentSpanId: spanOrder.spanId,
      serviceName: 'payment-service',
      operationName: 'PaymentService.ChargeCustomer',
      startTimeOffsetMs: 24,
      durationMs: paymentNode?.currentMetrics.latencyMs || 45,
      statusCode: isError ? 500 : 200,
      error: isError ? 'ConnectionPoolTimeout: db-cluster query blocked' : undefined,
      attributes: { 'payment.provider': 'stripe', currency: 'USD' },
    };

    const spanDb: Span = {
      traceId,
      spanId: `span_db_${this.currentTick}`,
      parentSpanId: spanPayment.spanId,
      serviceName: 'db-cluster',
      operationName: 'SELECT pg_advisory_xact_lock(account_id) FOR UPDATE',
      startTimeOffsetMs: 32,
      durationMs: dbNode?.currentMetrics.latencyMs || 22,
      statusCode: isError ? 500 : 200,
      error: isError ? 'QueryExecutionTimeout: lock wait timeout exceeded' : undefined,
      attributes: { 'db.system': 'postgresql', 'db.statement': 'SELECT * FROM accounts WHERE id = ? FOR UPDATE' },
    };

    const spansList = [spanRoot, spanCheckout, spanOrder, spanPayment, spanDb];
    for (const sp of spansList) {
      this.spanLookupMap.set(sp.spanId, sp);
    }

    const trace: TraceRecord = {
      traceId,
      rootService: 'api-gateway',
      operation: 'POST /v2/checkout/place-order',
      startTime: timestamp,
      totalDurationMs: spanRoot.durationMs,
      status: isError ? 'error' : 'ok',
      spans: spansList,
    };

    this.traceBuffer.unshift(trace);

    while (this.traceBuffer.length > this.maxTraceBufferSize) {
      const evicted = this.traceBuffer.pop();
      if (evicted) {
        for (const sp of evicted.spans) {
          this.spanLookupMap.delete(sp.spanId);
        }
      }
    }

    if (this.spanLookupMap.size > this.maxSpansInMap) {
      const activeIds = new Set(this.traceBuffer.flatMap((t) => t.spans.map((s) => s.spanId)));
      for (const k of this.spanLookupMap.keys()) {
        if (!activeIds.has(k)) {
          this.spanLookupMap.delete(k);
        }
      }
    }

    return trace;
  }
}

export const telemetryStore = new TelemetryStore();
