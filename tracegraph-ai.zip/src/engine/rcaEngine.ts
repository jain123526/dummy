import {
  ServiceNode,
  EdgeDependency,
  TraceRecord,
  RCAReport,
  RCAEvidence,
  EdgeAttribution,
  FeatureAttribution,
  FaultType,
} from '../types/telemetry';

export class EvidenceBasedRCAEngine {
  public detectTemporalOnset(node: ServiceNode): { onsetTick: number; onsetScore: number } {
    const history = node.history;
    if (!history || history.length < 3) return { onsetTick: 0, onsetScore: 0 };

    let maxDelta = 0;
    let onsetIndex = history.length - 1;

    for (let i = 1; i < history.length; i++) {
      const prev = history[i - 1];
      const curr = history[i];

      const latDelta = (curr.latencyMs - prev.latencyMs) / Math.max(10, prev.latencyMs);
      const errDelta = (curr.errorRate - prev.errorRate) * 10;
      const cpuDelta = (curr.cpuPct - prev.cpuPct) / 100;
      const totalDelta = Math.max(0, latDelta * 0.6 + errDelta * 0.8 + cpuDelta * 0.4);

      if (totalDelta > maxDelta && totalDelta > 0.4) {
        maxDelta = totalDelta;
        onsetIndex = i;
      }
    }

    const onsetTick = history[onsetIndex]?.tick ?? 0;
    return { onsetTick, onsetScore: maxDelta };
  }

  public analyzeRootCause(
    symptomNodeId: string,
    nodes: ServiceNode[],
    edges: EdgeDependency[],
    traces: TraceRecord[],
    edgeAttributions: EdgeAttribution[],
    featureAttributions: FeatureAttribution[],
    activeFaultType?: FaultType
  ): RCAReport {
    const nodeMap = new Map(nodes.map((n) => [n.id, n]));
    const targetNode = nodeMap.get(symptomNodeId) || nodes[0];
    const evidenceList: RCAEvidence[] = [];

    const outgoingMap = new Map<string, EdgeDependency[]>();
    const incomingMap = new Map<string, EdgeDependency[]>();
    for (const edge of edges) {
      if (!outgoingMap.has(edge.source)) outgoingMap.set(edge.source, []);
      outgoingMap.get(edge.source)?.push(edge);
      if (!incomingMap.has(edge.target)) incomingMap.set(edge.target, []);
      incomingMap.get(edge.target)?.push(edge);
    }

    const onsets = new Map<string, { onsetTick: number; onsetScore: number }>();
    for (const node of nodes) {
      onsets.set(node.id, this.detectTemporalOnset(node));
      node.temporalOnsetTime = onsets.get(node.id)?.onsetTick;
    }

    const visited = new Set<string>();
    const queue = [targetNode.id];
    const candidateNodes: string[] = [];

    while (queue.length > 0) {
      const curr = queue.shift()!;
      visited.add(curr);
      candidateNodes.push(curr);

      const callees = outgoingMap.get(curr) || [];
      for (const e of callees) {
        if (!visited.has(e.target)) {
          const calleeNode = nodeMap.get(e.target);
          if (calleeNode && calleeNode.anomalyScore >= 0.45) {
            queue.push(e.target);
          }
        }
      }
    }

    for (const node of nodes) {
      if (node.anomalyScore >= 0.75 && !candidateNodes.includes(node.id)) {
        candidateNodes.push(node.id);
      }
    }

    let bestCandidateId = targetNode.id;
    let highestEvidenceScore = -1;

    const validOnsets = candidateNodes
      .map((id) => onsets.get(id)?.onsetTick ?? 9999)
      .filter((t) => t !== 0);
    const minOnsetTick = validOnsets.length > 0 ? Math.min(...validOnsets) : 0;

    for (const candId of candidateNodes) {
      const node = nodeMap.get(candId);
      if (!node) continue;

      const gnnScore = node.anomalyScore;
      const onsetInfo = onsets.get(candId) || { onsetTick: 0, onsetScore: 0 };
      const isEarliest = onsetInfo.onsetTick === minOnsetTick && minOnsetTick !== 0;

      const temporalBonus = isEarliest ? 0.35 : (onsetInfo.onsetScore > 0.5 ? 0.15 : 0.0);

      const outgoingEdges = outgoingMap.get(candId) || [];
      const isLeafDependency = outgoingEdges.length === 0;
      const topoBonus = isLeafDependency ? 0.25 : 0.05;

      const incidentEdgeAttrs = edgeAttributions.filter(
        (ea) => ea.target === candId || ea.source === candId
      );
      const maxEdgeAttr = incidentEdgeAttrs.length > 0
        ? Math.max(...incidentEdgeAttrs.map((ea) => ea.importance))
        : 0;

      const callers = incomingMap.get(candId) || [];
      const anomalousCallers = callers.filter((c) => (nodeMap.get(c.source)?.anomalyScore || 0) >= 0.45);
      const calleeCausalBonus = Math.min(0.35, anomalousCallers.length * 0.15);

      const candidateScore =
        gnnScore * 0.35 +
        temporalBonus * 0.2 +
        topoBonus * 0.15 +
        maxEdgeAttr * 0.15 +
        calleeCausalBonus;

      if (candidateScore > highestEvidenceScore) {
        highestEvidenceScore = candidateScore;
        bestCandidateId = candId;
      }
    }

    const rootNode = nodeMap.get(bestCandidateId) || targetNode;
    const rootOnset = onsets.get(bestCandidateId);

    if (rootOnset && rootOnset.onsetScore > 0.4) {
      evidenceList.push({
        type: 'temporal_onset',
        description: `Temporal inflection detected on '${rootNode.name}' at history step (tick ${rootOnset.onsetTick}), preceding caller degradations.`,
        confidenceContribution: 0.32,
      });
    }

    const recentErrorTraces = traces.filter((t) => t.status === 'error');
    if (recentErrorTraces.length > 0) {
      const matchingSpan = recentErrorTraces[0].spans.find(
        (s) => s.serviceName === rootNode.name && s.statusCode >= 500
      );
      if (matchingSpan) {
        evidenceList.push({
          type: 'trace_dependency',
          description: `OTel trace span '${matchingSpan.spanId}' reported HTTP/gRPC ${matchingSpan.statusCode} with error: "${matchingSpan.error || 'Server Internal Error'}"`,
          confidenceContribution: 0.28,
        });
      }
    }

    const topFeat = featureAttributions[0];
    if (topFeat && topFeat.importance > 0.5) {
      evidenceList.push({
        type: 'feature_attribution',
        description: `GNNExplainer feature attribution identified '${topFeat.featureName}' as principal driver (${(topFeat.importance * 100).toFixed(0)}% importance, current: ${topFeat.currentVal} vs baseline ${topFeat.baselineVal}).`,
        confidenceContribution: 0.22,
      });
    }

    const highLatencyEdges = edgeAttributions.filter(
      (ea) => (ea.target === rootNode.id || ea.source === rootNode.id) && ea.latencyMs > 100
    );
    if (highLatencyEdges.length > 0) {
      const topEdge = highLatencyEdges[0];
      evidenceList.push({
        type: 'edge_latency',
        description: `Inter-service edge ${topEdge.source} -> ${topEdge.target} is saturated at ${topEdge.latencyMs}ms mean latency (${(topEdge.importance * 100).toFixed(0)}% causal attribution).`,
        confidenceContribution: 0.18,
      });
    }

    const propagationPath = this.tracePropagationPath(bestCandidateId, targetNode.id, outgoingMap, incomingMap);
    const baseConfidence = Math.min(0.98, Math.max(0.75, (rootNode.anomalyScore * 0.6) + (highestEvidenceScore * 0.4)));

    const summary = this.buildSummaryText(
      targetNode.name,
      rootNode.name,
      propagationPath,
      baseConfidence,
      activeFaultType
    );

    const nodeAttributions: Record<string, number> = {};
    for (const n of nodes) {
      let attr = n.anomalyScore;
      if (n.id === bestCandidateId) attr = Math.min(0.99, attr * 1.3);
      if (propagationPath.includes(n.id)) attr = Math.min(0.97, attr * 1.15);
      nodeAttributions[n.id] = Number(attr.toFixed(3));
    }

    return {
      incidentId: `inc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now(),
      targetNode: targetNode.name,
      rootCauseCandidate: rootNode.id,
      rootCauseConfidence: Number(baseConfidence.toFixed(2)),
      propagationPath,
      edgeAttributions: edgeAttributions.slice(0, 8),
      featureAttributions,
      nodeAttributions,
      evidenceList,
      explanationSummary: summary,
    };
  }

  private tracePropagationPath(
    rootId: string,
    symptomId: string,
    outgoingMap: Map<string, EdgeDependency[]>,
    incomingMap: Map<string, EdgeDependency[]>
  ): string[] {
    if (rootId === symptomId) return [rootId];

    const queue: string[][] = [[rootId]];
    const visited = new Set<string>([rootId]);

    while (queue.length > 0) {
      const path = queue.shift()!;
      const curr = path[path.length - 1];
      if (curr === symptomId) return path;

      const callers = incomingMap.get(curr) || [];
      for (const edge of callers) {
        if (!visited.has(edge.source)) {
          visited.add(edge.source);
          queue.push([...path, edge.source]);
        }
      }
    }

    const fwdQueue: string[][] = [[rootId]];
    const fwdVisited = new Set<string>([rootId]);

    while (fwdQueue.length > 0) {
      const path = fwdQueue.shift()!;
      const curr = path[path.length - 1];
      if (curr === symptomId) return path;

      const callees = outgoingMap.get(curr) || [];
      for (const edge of callees) {
        if (!fwdVisited.has(edge.target)) {
          fwdVisited.add(edge.target);
          fwdQueue.push([...path, edge.target]);
        }
      }
    }

    return [rootId, symptomId];
  }

  private buildSummaryText(
    symptomName: string,
    rootName: string,
    path: string[],
    confidence: number,
    faultType?: FaultType
  ): string {
    const faultDesc = faultType ? ` [Scenario: ${faultType.replace('_', ' ')}]` : '';
    if (symptomName === rootName) {
      return `Localized degradation identified on '${rootName}'${faultDesc}. Temporal GRU detected sudden inflection with elevated localized feature attribution. Root cause isolated directly to ${rootName} (Confidence: ${(confidence * 100).toFixed(0)}%).`;
    }
    return `Symptomatic timeout/error detected on '${symptomName}'. Multi-signal RCA combining temporal inflection, trace span exceptions, and GNNExplainer edge masks isolated the physical root cause to '${rootName}'${faultDesc}. Backpressure propagated along causal chain: ${path.join(' -> ')} (Confidence: ${(confidence * 100).toFixed(0)}%).`;
  }
}

export const rcaEngine = new EvidenceBasedRCAEngine();
