import React, { useState } from 'react';
import { ModelMetrics } from '../types/telemetry';
import { Brain, CheckCircle2, TrendingUp, Cpu, Gauge, Play, Loader2, AlertCircle } from 'lucide-react';
import { ColorTheme, THEMES } from '../types/theme';

interface ModelMetricsViewProps {
  metrics?: ModelMetrics;
  isTrained: boolean;
  onRetrain: () => Promise<void>;
  theme?: ColorTheme;
}

export const ModelMetricsView: React.FC<ModelMetricsViewProps> = ({
  metrics,
  isTrained,
  onRetrain,
  theme = 'violet',
}) => {
  const [training, setTraining] = useState<boolean>(false);
  const currentTheme = THEMES[theme];
  const isDark = currentTheme.isDark;

  const handleTrainClick = async () => {
    setTraining(true);
    try {
      await onRetrain();
    } finally {
      setTraining(false);
    }
  };

  return (
    <div
      className={`w-full flex flex-col gap-6 rounded-2xl border p-5 sm:p-6 transition-colors duration-200 shadow-xl ${
        isDark
          ? 'bg-slate-950 border-slate-800/80 text-white shadow-black/30'
          : 'bg-white/95 border-violet-200/90 text-slate-900 shadow-violet-200/40'
      }`}
    >
      {/* Header */}
      <div
        className={`flex flex-wrap items-center justify-between gap-4 border-b pb-4 transition-colors ${
          isDark ? 'border-slate-800' : 'border-violet-200/80'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              isDark
                ? 'bg-indigo-950/80 border border-indigo-700/60 text-indigo-400'
                : 'bg-violet-100 border border-violet-200 text-violet-700 shadow-xs'
            }`}
          >
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold tracking-tight">
                Spatial-Temporal GATv2 Model & Evaluation
              </h3>
              <span
                className={`text-xs px-2.5 py-0.5 rounded-md font-mono font-bold border transition-colors ${
                  isTrained
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-500'
                }`}
              >
                {isTrained ? 'STATUS: MODEL TRAINED' : 'STATUS: MODEL NOT TRAINED'}
              </span>
            </div>
            <p className={`text-xs font-mono mt-0.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Architecture: <span className="font-semibold text-indigo-500">GRU(T=20) &rarr; 4-Head GATv2Conv &rarr; MLP(16, 1)</span> | Checkpoint: <span className="font-mono">v2.1-prod-gatv2</span>
            </p>
          </div>
        </div>

        <button
          onClick={handleTrainClick}
          disabled={training}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 hover:opacity-95 disabled:opacity-50 text-white text-xs font-bold shadow-md shadow-purple-500/30 transition-all flex items-center gap-1.5 cursor-pointer ring-1 ring-white/20 hover:scale-105 active:scale-95"
        >
          {training ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
          <span>{training ? 'Training Model...' : 'Train / Retrain Model'}</span>
        </button>
      </div>

      {/* Model Metrics Cards */}
      {metrics ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div
            className={`p-3.5 rounded-xl border flex flex-col gap-1 ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <span className="text-[11px] text-slate-400 font-medium">Accuracy</span>
            <span className="text-2xl font-bold font-mono text-emerald-500">
              {(metrics.accuracy * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Test N={metrics.testSamples}</span>
          </div>

          <div
            className={`p-3.5 rounded-xl border flex flex-col gap-1 ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <span className="text-[11px] text-slate-400 font-medium">Precision / Recall</span>
            <span className="text-2xl font-bold font-mono text-indigo-400">
              {(metrics.precision * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              Recall: {(metrics.recall * 100).toFixed(1)}%
            </span>
          </div>

          <div
            className={`p-3.5 rounded-xl border flex flex-col gap-1 ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <span className="text-[11px] text-slate-400 font-medium">F1 Score</span>
            <span className="text-2xl font-bold font-mono text-cyan-400">
              {(metrics.f1 * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Harmonic Mean</span>
          </div>

          <div
            className={`p-3.5 rounded-xl border flex flex-col gap-1 ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <span className="text-[11px] text-slate-400 font-medium">AUROC</span>
            <span className="text-2xl font-bold font-mono text-purple-400">
              {(metrics.auroc * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] text-slate-500 font-mono">FPR: {(metrics.falsePositiveRate * 100).toFixed(1)}%</span>
          </div>

          <div
            className={`p-3.5 rounded-xl border flex flex-col gap-1 ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <span className="text-[11px] text-slate-400 font-medium">Top-1 RCA Accuracy</span>
            <span className="text-2xl font-bold font-mono text-amber-400">
              {(metrics.rcaTop1 * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Top-3: {(metrics.rcaTop3 * 100).toFixed(1)}%</span>
          </div>

          <div
            className={`p-3.5 rounded-xl border flex flex-col gap-1 ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <span className="text-[11px] text-slate-400 font-medium">Inference Latency</span>
            <span className="text-2xl font-bold font-mono text-rose-400">
              {metrics.meanInferenceLatencyMs.toFixed(1)} ms
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Per Graph Forward</span>
          </div>
        </div>
      ) : (
        <div
          className={`p-6 rounded-xl border border-dashed flex items-center gap-3 ${
            isDark ? 'bg-rose-950/20 border-rose-900 text-rose-300' : 'bg-rose-50 border-rose-200 text-rose-700'
          }`}
        >
          <AlertCircle className="w-6 h-6 shrink-0" />
          <div>
            <h4 className="font-bold text-sm">Model Not Trained</h4>
            <p className="text-xs opacity-80 mt-0.5">
              Click &quot;Train / Retrain Model&quot; to execute parameter optimization across synthetic microservice failure scenarios.
            </p>
          </div>
        </div>
      )}

      {/* Loss Curves & Convergence Details */}
      {metrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div
            className={`p-4 rounded-xl border flex flex-col gap-2 ${
              isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
                Training &amp; Validation Loss Convergence
              </span>
              <span className="font-mono text-[10px] text-slate-400">Epochs: {metrics.epochCount}</span>
            </div>

            <div className="h-32 flex items-end gap-2 pt-4 px-2 border-b pb-2">
              {metrics.trainLoss.map((tl, idx) => {
                const vl = metrics.valLoss[idx] ?? tl;
                const hTrain = Math.min(100, Math.max(10, tl * 120));
                const hVal = Math.min(100, Math.max(10, vl * 120));
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                    <div className="w-full flex items-end justify-center gap-1 h-full">
                      <div
                        className="w-1/2 bg-indigo-500 rounded-t-sm transition-all"
                        style={{ height: `${hTrain}%` }}
                        title={`Epoch ${idx + 1} Train Loss: ${tl}`}
                      />
                      <div
                        className="w-1/2 bg-purple-400 rounded-t-sm transition-all"
                        style={{ height: `${hVal}%` }}
                        title={`Epoch ${idx + 1} Val Loss: ${vl}`}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-slate-500">e{idx + 1}</span>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 bg-indigo-500 rounded-xs inline-block" /> Train Loss: {metrics.trainLoss[metrics.trainLoss.length - 1]}
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 bg-purple-400 rounded-xs inline-block" /> Val Loss: {metrics.valLoss[metrics.valLoss.length - 1]}
              </div>
            </div>
          </div>

          <div
            className={`p-4 rounded-xl border flex flex-col gap-2.5 text-xs font-mono ${
              isDark ? 'bg-slate-900/40 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <span className="font-semibold text-slate-200 flex items-center gap-1.5 font-sans">
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
              Dataset &amp; Split Specification
            </span>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <span className="text-slate-400 block">Total Graph Snapshots:</span>
                <span className="font-bold">{metrics.trainingSamples + metrics.testSamples}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Chronological Split:</span>
                <span className="font-bold">70% Train / 15% Val / 15% Test</span>
              </div>
              <div>
                <span className="text-slate-400 block">Node Feature Dim:</span>
                <span className="font-bold">F = 5 [Lat, Err, RPS, CPU, Mem]</span>
              </div>
              <div>
                <span className="text-slate-400 block">Edge Feature Dim:</span>
                <span className="font-bold">E = 3 [Lat, Err, RPS]</span>
              </div>
              <div>
                <span className="text-slate-400 block">Attention Heads:</span>
                <span className="font-bold">K = 4 Heads</span>
              </div>
              <div>
                <span className="text-slate-400 block">Temporal Encoder:</span>
                <span className="font-bold">GRU (Hidden = 32)</span>
              </div>
            </div>
            <div className="mt-1 p-2 rounded-lg bg-black/20 border border-white/5 text-[10px] text-slate-400 leading-relaxed font-sans">
              Dynamic threshold &tau; is continually updated from baseline_stats to eliminate 90%+ storage waste while preserving critical root-cause telemetry.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
