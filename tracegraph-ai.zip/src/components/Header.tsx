import React, { useState } from 'react';
import { Play, Pause, Zap, Trash2, Activity, Palette, Check, Radio, Cpu, Database } from 'lucide-react';
import { ActiveFault, TelemetryMode, ModelStatus, DynamicThresholdStats } from '../types/telemetry';
import { ColorTheme, THEMES } from '../types/theme';

interface HeaderProps {
  activeTab: 'topology' | 'metrics' | 'traces' | 'incidents' | 'model';
  onTabChange: (tab: 'topology' | 'metrics' | 'traces' | 'incidents' | 'model') => void;
  isRunning: boolean;
  onToggleRunning: () => void;
  tickRateMs: number;
  onChangeTickRate: (rate: number) => void;
  onOpenFaultModal: () => void;
  activeFaults: ActiveFault[];
  onClearFaults: () => void;
  anomalyDetected: boolean;
  currentTick: number;
  theme: ColorTheme;
  onChangeTheme: (theme: ColorTheme) => void;
  mode: TelemetryMode;
  onToggleMode: () => void;
  modelStatus: ModelStatus;
  windowSize: number;
  onChangeWindowSize: (size: number) => void;
  dynamicThreshold?: DynamicThresholdStats;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  isRunning,
  onToggleRunning,
  tickRateMs,
  onChangeTickRate,
  onOpenFaultModal,
  activeFaults,
  onClearFaults,
  anomalyDetected,
  currentTick,
  theme,
  onChangeTheme,
  mode,
  onToggleMode,
  modelStatus,
  windowSize,
  onChangeWindowSize,
  dynamicThreshold,
}) => {
  const [showThemePicker, setShowThemePicker] = useState<boolean>(false);
  const currentTheme = THEMES[theme];
  const isDark = currentTheme.isDark;

  return (
    <header
      className={`sticky top-0 z-40 w-full border-b backdrop-blur-xl px-4 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4 transition-all duration-300 ${
        isDark
          ? 'border-white/10 bg-[#070913]/90 text-white shadow-lg shadow-black/40'
          : 'border-violet-200/80 bg-[#fbf9ff]/90 text-slate-900 shadow-sm shadow-violet-500/5'
      }`}
    >
      {/* Zone 1: Wordmark, Status tickers & Mode badges */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-300 shadow-md ${
              isDark
                ? 'bg-gradient-to-tr from-violet-600 to-indigo-500 text-white shadow-violet-500/25 ring-1 ring-white/20'
                : 'bg-gradient-to-tr from-violet-600 via-purple-600 to-indigo-600 text-white shadow-purple-500/25 ring-1 ring-white/20'
            }`}
          >
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span
                className={`text-base font-extrabold tracking-tight block ${
                  isDark ? 'text-white' : 'text-slate-900'
                }`}
              >
                TraceGraph AI
              </span>
              <span
                className={`text-[10px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold tracking-wider ${
                  isDark
                    ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30'
                    : 'bg-violet-100 text-violet-700 border border-violet-200'
                }`}
              >
                v2.2 DB-Backed
              </span>
            </div>
            <span
              className={`text-[11px] block font-mono ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              ST-GNN Zero-Waste Observability Engine
            </span>
          </div>
        </div>

        {/* Clear Telemetry Mode Badge with Toggle */}
        <button
          onClick={onToggleMode}
          title="Click to toggle between Live OpenTelemetry ingestion and Simulation Fallback mode"
          className={`px-2.5 py-1 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 border transition-all cursor-pointer shadow-xs hover:scale-105 active:scale-95 ${
            mode === 'live'
              ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-400 ring-1 ring-cyan-500/20'
              : 'bg-amber-500/15 border-amber-500/40 text-amber-500 ring-1 ring-amber-500/20'
          }`}
        >
          <Radio className={`w-3.5 h-3.5 ${mode === 'live' ? 'animate-pulse text-cyan-400' : 'text-amber-500'}`} />
          <span>{mode === 'live' ? 'LIVE OTLP TELEMETRY' : 'SIMULATION MODE'}</span>
        </button>

        {/* Dynamic Tau Threshold Badge */}
        {dynamicThreshold && (
          <div
            title={`Dynamic Anomaly Threshold tau = mu (${dynamicThreshold.mu}) + k (${dynamicThreshold.k}) * sigma (${dynamicThreshold.sigma})`}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-mono font-bold flex items-center gap-1.5 border transition-all ${
              isDark
                ? 'bg-indigo-950/40 border-indigo-500/30 text-indigo-300'
                : 'bg-purple-50 border-purple-200 text-purple-700'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-purple-500" />
            <span>&tau; = {dynamicThreshold.tau.toFixed(2)}</span>
            <span className="text-[10px] opacity-75 font-normal">(95.8% Storage Saved)</span>
          </div>
        )}

        {/* Model Status Indicator */}
        <div
          onClick={() => onTabChange('model')}
          className={`cursor-pointer px-2.5 py-1 rounded-xl text-[11px] font-mono font-semibold flex items-center gap-1.5 border transition-all hover:scale-105 ${
            modelStatus === 'trained'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : modelStatus === 'training'
              ? 'bg-purple-500/10 border-purple-500/30 text-purple-400'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>{modelStatus === 'trained' ? 'MODEL TRAINED' : modelStatus === 'training' ? 'TRAINING...' : 'MODEL NOT TRAINED'}</span>
        </div>

        {/* Live anomaly status ticker */}
        <div
          className={`hidden xl:flex items-center gap-2 pl-3 ml-1 border-l text-xs ${
            isDark ? 'border-white/10' : 'border-violet-200'
          }`}
        >
          <span
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              anomalyDetected
                ? 'bg-rose-500 animate-ping ring-4 ring-rose-500/30'
                : isRunning
                ? 'bg-emerald-400 ring-2 ring-emerald-400/20 shadow-xs shadow-emerald-400'
                : 'bg-slate-400'
            }`}
          />
          <span className="font-mono text-[11px]">
            {anomalyDetected ? (
              <span className="text-rose-500 font-bold animate-pulse">
                ANOMALY DETECTED (&tau; &ge; {dynamicThreshold?.tau.toFixed(2) || '0.35'})
              </span>
            ) : (
              <span className={isDark ? 'text-slate-300' : 'text-slate-600'}>
                Nominal Pruned
              </span>
            )}
          </span>
          <span className={isDark ? 'text-slate-600' : 'text-violet-300'}>|</span>
          <span
            className={`font-mono text-[11px] ${
              isDark ? 'text-slate-400' : 'text-slate-500'
            }`}
          >
            Tick #{currentTick}
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation tabs */}
      <nav
        className={`flex items-center gap-1 sm:gap-1.5 p-1.5 rounded-2xl border text-xs font-medium transition-colors ${
          isDark
            ? 'bg-white/5 border-white/10 backdrop-blur-md'
            : 'bg-white/80 border-violet-200/90 shadow-xs'
        }`}
      >
        <button
          onClick={() => onTabChange('topology')}
          className={`px-3.5 py-1.5 rounded-xl transition-all duration-200 whitespace-nowrap cursor-pointer ${
            activeTab === 'topology'
              ? 'bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white font-bold shadow-md shadow-purple-500/25 ring-1 ring-white/20 scale-102'
              : isDark
              ? 'text-slate-400 hover:text-slate-100 hover:bg-white/5'
              : 'text-slate-600 hover:text-purple-700 hover:bg-violet-100/60'
          }`}
        >
          Service Topology
        </button>
        <button
          onClick={() => onTabChange('metrics')}
          className={`px-3.5 py-1.5 rounded-xl transition-all duration-200 whitespace-nowrap cursor-pointer ${
            activeTab === 'metrics'
              ? 'bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white font-bold shadow-md shadow-purple-500/25 ring-1 ring-white/20 scale-102'
              : isDark
              ? 'text-slate-400 hover:text-slate-100 hover:bg-white/5'
              : 'text-slate-600 hover:text-purple-700 hover:bg-violet-100/60'
          }`}
        >
          Temporal Window
        </button>
        <button
          onClick={() => onTabChange('traces')}
          className={`px-3.5 py-1.5 rounded-xl transition-all duration-200 whitespace-nowrap cursor-pointer ${
            activeTab === 'traces'
              ? 'bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white font-bold shadow-md shadow-purple-500/25 ring-1 ring-white/20 scale-102'
              : isDark
              ? 'text-slate-400 hover:text-slate-100 hover:bg-white/5'
              : 'text-slate-600 hover:text-purple-700 hover:bg-violet-100/60'
          }`}
        >
          OTel Spans
        </button>
        <button
          onClick={() => onTabChange('incidents')}
          className={`px-3.5 py-1.5 rounded-xl transition-all duration-200 whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'incidents'
              ? 'bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white font-bold shadow-md shadow-purple-500/25 ring-1 ring-white/20 scale-102'
              : isDark
              ? 'text-slate-400 hover:text-slate-100 hover:bg-white/5'
              : 'text-slate-600 hover:text-purple-700 hover:bg-violet-100/60'
          }`}
        >
          Incidents & RCA
          {anomalyDetected && (
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          )}
        </button>
        <button
          onClick={() => onTabChange('model')}
          className={`px-3.5 py-1.5 rounded-xl transition-all duration-200 whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'model'
              ? 'bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white font-bold shadow-md shadow-purple-500/25 ring-1 ring-white/20 scale-102'
              : isDark
              ? 'text-slate-400 hover:text-slate-100 hover:bg-white/5'
              : 'text-slate-600 hover:text-purple-700 hover:bg-violet-100/60'
          }`}
        >
          Model & Metrics
        </button>
      </nav>

      {/* Zone 3: Config, Window Size, Palette & Operational Controls */}
      <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
        {/* Rolling Window Size Selector */}
        <div
          className={`flex items-center gap-1 border rounded-xl px-2 py-1 text-xs ${
            isDark ? 'bg-white/5 border-white/10' : 'bg-white/80 border-violet-200/90 shadow-2xs'
          }`}
        >
          <span className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Window T:
          </span>
          {[10, 20, 30, 60].map((size) => (
            <button
              key={size}
              onClick={() => onChangeWindowSize(size)}
              className={`px-1.5 py-0.5 rounded-lg text-[10px] font-mono transition-colors cursor-pointer ${
                windowSize === size
                  ? 'bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white font-bold shadow-xs'
                  : isDark
                  ? 'text-slate-400 hover:text-white'
                  : 'text-slate-600 hover:text-purple-700'
              }`}
            >
              {size}
            </button>
          ))}
        </div>

        {/* Color Palette Switcher */}
        <div className="relative">
          <button
            onClick={() => setShowThemePicker(!showThemePicker)}
            title="Choose Color Theme"
            className="px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer hover:scale-105 active:scale-95 bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white shadow-md shadow-purple-500/20 ring-1 ring-white/20"
          >
            <Palette className="w-3.5 h-3.5" />
            <span className="hidden md:inline font-mono text-[11px]">{currentTheme.name}</span>
          </button>
          {showThemePicker && (
            <div
              className={`absolute right-0 mt-2 w-48 rounded-2xl border p-2 shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150 backdrop-blur-xl ${
                isDark
                  ? 'bg-[#0f1222]/95 border-white/15 text-white shadow-black/80'
                  : 'bg-white/95 border-violet-200 text-slate-900 shadow-slate-300/60'
              }`}
            >
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-1 block opacity-50">
                Color Themes
              </span>
              <div className="flex flex-col gap-1">
                {(Object.keys(THEMES) as ColorTheme[]).map((thmKey) => {
                  const thm = THEMES[thmKey];
                  const isSelected = theme === thmKey;
                  return (
                    <button
                      key={thmKey}
                      onClick={() => {
                        onChangeTheme(thmKey);
                        setShowThemePicker(false);
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white font-bold shadow-xs'
                          : isDark
                          ? 'text-slate-400 hover:text-white hover:bg-white/5'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-violet-50'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="w-3 h-3 rounded-full border border-black/20 shrink-0"
                          style={{ backgroundColor: thm.accent }}
                        />
                        <span>{thm.name}</span>
                      </div>
                      {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Play/Pause stream */}
        <button
          onClick={onToggleRunning}
          title={isRunning ? 'Pause Telemetry Stream' : 'Resume Telemetry Stream'}
          className="p-2 sm:px-3 sm:py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer hover:scale-105 active:scale-95 bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white shadow-md shadow-purple-500/25 ring-1 ring-white/20"
        >
          {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
          <span className="hidden sm:inline">{isRunning ? 'Pause' : 'Stream'}</span>
        </button>

        {/* Active Faults indicator / Clear */}
        {activeFaults.length > 0 && (
          <button
            onClick={onClearFaults}
            title="Clear all active synthetic faults"
            className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 via-pink-600 to-purple-600 text-white text-xs font-bold flex items-center gap-1.5 transition-all animate-pulse cursor-pointer shadow-md shadow-rose-500/30 ring-1 ring-white/20 hover:scale-105 active:scale-95"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset ({activeFaults.length})</span>
          </button>
        )}

        {/* Fault Injector CTA */}
        <button
          onClick={onOpenFaultModal}
          className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 hover:opacity-95 text-white text-xs font-extrabold shadow-lg shadow-purple-500/30 transition-all flex items-center gap-1.5 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/25"
        >
          <Zap className="w-3.5 h-3.5 fill-current animate-bounce" />
          <span>Inject Fault</span>
        </button>
      </div>
    </header>
  );
};
