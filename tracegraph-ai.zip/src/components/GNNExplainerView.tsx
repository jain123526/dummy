import React from 'react';
import { RCAReport } from '../types/telemetry';
import { ShieldAlert, ArrowRight, Zap, Target, BookOpen, Layers, BarChart } from 'lucide-react';
import { ColorTheme, THEMES } from '../types/theme';

interface GNNExplainerViewProps {
  rca: RCAReport | null;
  onSelectNode?: (nodeId: string) => void;
  theme?: ColorTheme;
}

export const GNNExplainerView: React.FC<GNNExplainerViewProps> = ({ rca, onSelectNode, theme = 'violet' }) => {
  const currentTheme = THEMES[theme];
  const isDark = currentTheme.isDark;

  if (!rca) {
    return (
      <div
        className={`w-full rounded-2xl border p-8 flex flex-col items-center justify-center text-center transition-colors ${
          isDark
            ? 'border-slate-800 bg-slate-900/40 text-slate-300'
            : 'border-slate-200 bg-white text-slate-700 shadow-sm'
        }`}
      >
        <ShieldAlert className="w-8 h-8 text-slate-400 mb-2" />
        <h4 className="text-sm font-semibold">GNNExplainer Engine Idle</h4>
        <p className="text-xs text-slate-500 mt-1 max-w-md">
          Cluster nominal (&tau; &lt; dynamic threshold). When an anomaly occurs or when you inject a chaos scenario, GNNExplainer optimizes continuous edge masks <span className="font-mono text-indigo-500">M_e</span> and feature masks <span className="font-mono text-indigo-500">M_f</span> via mutual information maximization.
        </p>
      </div>
    );
  }

  return (
    <div
      className={`w-full flex flex-col gap-6 rounded-2xl border p-6 transition-colors duration-200 shadow-xl ${
        isDark
          ? 'bg-slate-950 border-rose-900/40 text-white shadow-black/30'
          : 'bg-white/95 border-violet-200/90 text-slate-900 shadow-violet-200/40'
      }`}
    >
      {/* Top Banner */}
      <div
        className={`flex flex-wrap items-center justify-between gap-4 border-b pb-4 transition-colors ${
          isDark ? 'border-rose-900/40' : 'border-violet-200/80'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              isDark
                ? 'bg-rose-950/80 border border-rose-700/60 text-rose-400'
                : 'bg-rose-50 border border-rose-200 text-rose-600 shadow-xs'
            }`}
          >
            <Target className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold tracking-tight">
                Canonical GNNExplainer &amp; Causal Attribution
              </h3>
              <span
                className={`text-xs px-2.5 py-0.5 rounded-md font-mono border ${
                  isDark
                    ? 'bg-rose-950 text-rose-300 border-rose-700'
                    : 'bg-rose-50 text-rose-600 border-rose-200'
                }`}
              >
                Confidence: {(rca.rootCauseConfidence * 100).toFixed(0)}%
              </span>
            </div>
            <p className={`text-xs mt-0.5 font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Incident ID: <span className="font-bold">{rca.incidentId}</span> | Method: <span className="text-indigo-400 font-semibold">Continuous Mask MI Optimization</span>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono">
          <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Root Cause Culprit:</span>
          <span className="bg-gradient-to-r from-rose-600 via-pink-600 to-red-600 text-white font-bold px-3.5 py-1 rounded-xl shadow-md shadow-rose-500/25 ring-1 ring-white/20">
            {rca.rootCauseCandidate}
          </span>
        </div>
      </div>

      {/* Causal Cascade Timeline */}
      <div
        className={`flex flex-col gap-2 p-4 rounded-xl border transition-colors ${
          isDark
            ? 'bg-slate-900/60 border-slate-800'
            : 'bg-rose-50/40 border-rose-100'
        }`}
      >
        <span className="text-xs font-semibold">
          Causal Propagation Cascade: Root Cause &rarr; Upstream Victims
        </span>
        <div className="flex items-center gap-2 overflow-x-auto py-2">
          {rca.propagationPath.map((nodeName, idx) => {
            const isRoot = nodeName === rca.rootCauseCandidate;
            const isTarget = nodeName === rca.targetNode;
            return (
              <React.Fragment key={nodeName}>
                <div
                  onClick={() => onSelectNode?.(nodeName)}
                  className={`cursor-pointer px-3 py-2 rounded-xl border transition-all text-xs font-mono flex flex-col items-center min-w-[120px] hover:scale-102 ${
                    isRoot
                      ? 'bg-rose-600 text-white border-rose-700 shadow-md shadow-rose-600/20'
                      : isTarget
                      ? isDark
                        ? 'bg-amber-950/60 border-amber-600 text-amber-200'
                        : 'bg-amber-50 border-amber-300 text-amber-800'
                      : isDark
                      ? 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-500'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-400 shadow-2xs'
                  }`}
                >
                  <span className={`text-[10px] uppercase tracking-wider mb-0.5 ${isRoot ? 'text-rose-100' : 'opacity-70'}`}>
                    {isRoot ? '1. Root Cause' : isTarget ? 'Symptom Entry' : `Step ${idx + 1}`}
                  </span>
                  <span className="font-bold">{nodeName}</span>
                </div>
                {idx < rca.propagationPath.length - 1 && (
                  <ArrowRight className="w-4 h-4 text-rose-500 shrink-0" />
                )}
              </React.Fragment>
            );
          })}
        </div>
        <p className={`text-xs mt-2 leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
          {rca.explanationSummary}
        </p>
      </div>

      {/* Feature & Edge Attribution Side-by-Side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Edge Attributions Table */}
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              Edge Importance Mask (M_e)
            </h4>
            <span className={`text-[10px] font-mono ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
              min ||M_e||_1 + H(M_e)
            </span>
          </div>

          <div
            className={`overflow-x-auto rounded-xl border transition-colors ${
              isDark ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <table className="w-full text-xs font-mono">
              <thead>
                <tr
                  className={`border-b text-[11px] ${
                    isDark
                      ? 'bg-slate-900 border-slate-800 text-slate-400'
                      : 'bg-slate-50 border-slate-200 text-slate-500'
                  }`}
                >
                  <th className="py-2 px-2.5 text-left">Edge</th>
                  <th className="py-2 px-2 text-right">Lat</th>
                  <th className="py-2 px-2 text-right">Err%</th>
                  <th className="py-2 px-2.5 text-left w-36">Attribution</th>
                </tr>
              </thead>
              <tbody
                className={`divide-y ${
                  isDark ? 'divide-slate-900' : 'divide-slate-200/60'
                }`}
              >
                {rca.edgeAttributions.slice(0, 5).map((ea, idx) => (
                  <tr
                    key={idx}
                    className={`transition-colors ${
                      isDark ? 'hover:bg-slate-900/50' : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className="py-2 px-2.5 font-semibold text-[11px]">
                      {ea.source} &rarr; {ea.target}
                    </td>
                    <td className={`py-2 px-2 text-right text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>{ea.latencyMs}ms</td>
                    <td className={`py-2 px-2 text-right text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>{(ea.errorRate * 100).toFixed(1)}%</td>
                    <td className="py-2 px-2.5">
                      <div className="flex items-center gap-2">
                        <div
                          className={`flex-1 h-2 rounded-full overflow-hidden ${
                            isDark ? 'bg-slate-800' : 'bg-slate-200'
                          }`}
                        >
                          <div
                            className="h-full bg-gradient-to-r from-rose-500 to-rose-600 rounded-full"
                            style={{ width: `${Math.min(100, ea.importance * 100)}%` }}
                          />
                        </div>
                        <span className="text-[10px] font-bold text-rose-500 w-8 text-right">
                          {(ea.importance * 100).toFixed(0)}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Node Feature Attributions (M_f) */}
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold flex items-center gap-1.5">
              <BarChart className="w-3.5 h-3.5 text-cyan-400" />
              Node Feature Attribution (M_f)
            </h4>
            <span className={`text-[10px] font-mono ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
              Deviation vs Baseline
            </span>
          </div>

          <div
            className={`p-3 rounded-xl border flex flex-col gap-2 transition-colors ${
              isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            {(rca.featureAttributions || []).map((fa, idx) => (
              <div key={idx} className="flex flex-col gap-1 text-xs font-mono">
                <div className="flex items-center justify-between text-[11px]">
                  <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>
                    {fa.featureName}
                  </span>
                  <div className="flex items-center gap-2 text-[10px]">
                    <span className="opacity-75">
                      val: {fa.currentVal} (base: {fa.baselineVal})
                    </span>
                    <span className="font-bold text-rose-500">
                      {(fa.importance * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
                <div className={`w-full h-2 rounded-full overflow-hidden ${isDark ? 'bg-slate-800' : 'bg-slate-200'}`}>
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-rose-500 rounded-full"
                    style={{ width: `${Math.min(100, fa.importance * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Multi-Factor Structured Evidence Breakdown */}
      {rca.evidenceList && rca.evidenceList.length > 0 && (
        <div className="flex flex-col gap-2">
          <h4 className="text-xs font-semibold flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            Empirical RCA Evidence Log
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs font-mono">
            {rca.evidenceList.map((ev, idx) => (
              <div
                key={idx}
                className={`p-2.5 rounded-xl border flex flex-col gap-1 ${
                  isDark ? 'bg-slate-900/60 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-indigo-400 font-bold uppercase tracking-wider">
                    [{ev.type.replace('_', ' ')}]
                  </span>
                  <span className="text-emerald-400 font-semibold">
                    +{(ev.confidenceContribution * 100).toFixed(0)}% weight
                  </span>
                </div>
                <p className="text-[11px] font-sans leading-snug">{ev.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Mathematical Architecture Primer */}
      <div
        className={`p-4 rounded-xl border text-xs flex flex-col gap-2 transition-colors ${
          isDark
            ? 'bg-slate-900/50 border-slate-800/80 text-slate-300'
            : 'bg-slate-50 border-slate-200 text-slate-700'
        }`}
      >
        <div className="flex items-center gap-2 text-indigo-600 font-semibold">
          <BookOpen className="w-4 h-4" />
          <span>Spatial-Temporal GNN &amp; GNNExplainer Mathematical Equations</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-1 font-mono text-[11px]">
          <div
            className={`p-3 rounded-lg border ${
              isDark
                ? 'bg-slate-950 border-slate-800/60 text-slate-400'
                : 'bg-white border-slate-200 text-slate-600 shadow-2xs'
            }`}
          >
            <span className={`font-semibold block mb-1 ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>
              1. Temporal GRU Encoder
            </span>
            <code className="text-indigo-500">h_i = GRU(X_i)_{'{t=T}'} \in R^{32}</code>
            <p className="mt-1 text-[10px] opacity-75 font-sans">
              Encodes multivariate series [latency, err, rps, cpu, mem] across sliding history.
            </p>
          </div>
          <div
            className={`p-3 rounded-lg border ${
              isDark
                ? 'bg-slate-950 border-slate-800/60 text-slate-400'
                : 'bg-white border-slate-200 text-slate-600 shadow-2xs'
            }`}
          >
            <span className={`font-semibold block mb-1 ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>
              2. Multi-Head GATv2Conv
            </span>
            <code className="text-indigo-500">{"\u03B1_ij = softmax(a^T LeakyReLU(W_s h_i + W_t h_j + W_e e_ij))"}</code>
            <p className="mt-1 text-[10px] opacity-75 font-sans">
              Learns directed caller-callee attention with dynamic RPC latency & error edge projections.
            </p>
          </div>
          <div
            className={`p-3 rounded-lg border ${
              isDark
                ? 'bg-slate-950 border-slate-800/60 text-slate-400'
                : 'bg-white border-slate-200 text-slate-600 shadow-2xs'
            }`}
          >
            <span className={`font-semibold block mb-1 ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>
              3. Dynamic Threshold &amp; Zero-Waste
            </span>
            <code className="text-indigo-500">&tau; = &mu;_base + k &times; &sigma;_base</code>
            <p className="mt-1 text-[10px] opacity-75 font-sans">
              Persists only abnormal traces (&ge; &tau;) in database; prunes nominal traces to save 90%+ storage.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
