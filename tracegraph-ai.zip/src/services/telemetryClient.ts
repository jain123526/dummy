import {
  TelemetrySnapshot,
  FaultType,
  RCAReport,
  TelemetryMode,
  ModelMetrics,
  createInitialSnapshot,
  IncidentRecord,
} from '../types/telemetry';

let lastKnownSnapshot: TelemetrySnapshot = createInitialSnapshot();

export const telemetryClient = {
  async fetchSnapshot(): Promise<TelemetrySnapshot> {
    try {
      const res = await fetch('/api/telemetry/snapshot');
      if (res.ok) {
        const data = await res.json();
        lastKnownSnapshot = data;
        return data;
      }
    } catch {
      // Fallback to last known snapshot
    }
    return lastKnownSnapshot;
  },

  async triggerFault(
    faultType: FaultType,
    targetService: string,
    durationTicks: number = 15,
    magnitude: number = 3.5,
    isRealEnv: boolean = false
  ): Promise<void> {
    try {
      await fetch('/api/faults/inject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ faultType, targetService, durationTicks, magnitude, isRealEnv }),
      });
    } catch {}
  },

  async clearAllFaults(): Promise<void> {
    try {
      await fetch('/api/faults/reset', { method: 'POST' });
    } catch {}
  },

  async clearFault(faultId: string): Promise<void> {
    try {
      await fetch('/api/faults/reset', { method: 'POST' });
    } catch {}
  },

  async setMode(mode: TelemetryMode): Promise<void> {
    try {
      await fetch('/api/system/mode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode }),
      });
    } catch {}
  },

  async setWindowSize(windowSize: number): Promise<void> {
    try {
      await fetch('/api/system/window-size', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ windowSize }),
      });
    } catch {}
  },

  async trainModel(): Promise<{ success: boolean; metrics?: ModelMetrics }> {
    try {
      const res = await fetch('/api/model/train', { method: 'POST' });
      if (res.ok) {
        return await res.json();
      }
    } catch {}
    return { success: true };
  },

  async evaluateModel(): Promise<{ success: boolean; metrics?: ModelMetrics }> {
    try {
      const res = await fetch('/api/model/evaluate', { method: 'POST' });
      if (res.ok) {
        return await res.json();
      }
    } catch {}
    return { success: true };
  },

  async generatePlaybook(rca: RCAReport): Promise<string> {
    try {
      const res = await fetch('/api/ai/playbook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rca }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.playbook) return data.playbook;
      }
    } catch {}
    return `### Remediation Runbook for ${rca.rootCauseCandidate}\nExecute immediate diagnostic on ${rca.rootCauseCandidate}. Trace cascade path: ${rca.propagationPath.join(' -> ')}.`;
  },

  async resolveIncident(id: string): Promise<void> {
    try {
      await fetch(`/api/incidents/${id}/resolve`, { method: 'POST' });
    } catch {}
  },

  async fetchIncidents(): Promise<IncidentRecord[]> {
    try {
      const res = await fetch('/api/incidents');
      if (res.ok) {
        return await res.json();
      }
    } catch {}
    return lastKnownSnapshot.incidents || [];
  },

  async fetchPruningStats(): Promise<any> {
    try {
      const res = await fetch('/api/v1/stats');
      if (res.ok) {
        return await res.json();
      }
    } catch {}
    return null;
  },
};
