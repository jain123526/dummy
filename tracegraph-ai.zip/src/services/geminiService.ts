import { RCAReport } from '../types/telemetry';
import { telemetryClient } from './telemetryClient';

export async function generateIncidentPlaybook(rca: RCAReport): Promise<string> {
  return telemetryClient.generatePlaybook(rca);
}
