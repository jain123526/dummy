/**
 * TraceGraph AI — Automated Test Suite & Database Verification
 * Validates:
 * 1. Database Initialization & Schema (services, baseline_stats, anomalous_microservices, anomalous_spans)
 * 2. Dynamic Threshold tau = mu + k * sigma calculation
 * 3. Zero-Waste Pruning: Nominal traces pruned immediately
 * 4. Anomaly Retention: Abnormal microservices exceeding tau persisted to database
 * 5. ST-GNN Forward Pass & GNNExplainer Continuous Masks
 * 6. Evidence-Based RCA and Causal Cascade Isolation
 */

import { dbClient } from '../src/db/database';
import { telemetryStore } from '../src/engine/telemetryStore';
import { stGnnModel } from '../src/engine/stGnnModel';
import { rcaEngine } from '../src/engine/rcaEngine';

function assert(condition: boolean, msg: string) {
  if (!condition) {
    console.error(`❌ FAILED: ${msg}`);
    process.exit(1);
  }
  console.log(`✅ PASSED: ${msg}`);
}

async function runTestSuite() {
  console.log('===============================================================');
  console.log('  TraceGraph AI — Persistent DB & Zero-Waste Verification Tests');
  console.log('===============================================================');

  // Test 1: Database Initialization & Tables Creation
  console.log('\n--- 1. Database Schema & Persistence Adapter ---');
  await dbClient.initDb();
  const services = await dbClient.getServices();
  assert(services.length >= 10, `Database contains ${services.length} services (expected >= 10)`);
  assert(services.some((s) => s.id === 'db-cluster'), 'Service db-cluster registered in database');
  assert(services.some((s) => s.id === 'api-gateway'), 'Service api-gateway registered in database');

  // Test 2: Baseline Stats & Dynamic Threshold tau calculation
  console.log('\n--- 2. Mathematical Dynamic Threshold tau Calculation ---');
  const baselineStats = await dbClient.getAllBaselineStats();
  assert(baselineStats.length > 0, `baseline_stats table populated (${baselineStats.length} rows)`);

  const initialTau = await dbClient.computeDynamicThreshold(3.0);
  console.log(`  Initial Tau: tau=${initialTau.tau}, mu=${initialTau.mu}, sigma=${initialTau.sigma}, k=${initialTau.k}`);
  assert(initialTau.tau > 0.1 && initialTau.tau < 1.0, 'Dynamic threshold tau is calculated within valid range');
  const expectedTau = Number((initialTau.mu + 3.0 * initialTau.sigma).toFixed(4));
  assert(Math.abs(initialTau.tau - expectedTau) < 0.001, 'Tau precisely matches tau = mu + k * sigma formula');

  // Test 3: Zero-Waste Nominal Trace Pruning Verification
  console.log('\n--- 3. Zero-Waste Retention: Nominal Trace Pruning ---');
  const beforePruningMetrics = await dbClient.getPruningMetrics();
  const initialAnomCount = (await dbClient.getAnomalousIncidents(100)).length;

  // Process nominal trace
  dbClient.recordNominalPruned(5);
  await dbClient.updateBaselineWithSample('cluster-wide', 'reconstruction_mse', 0.165);

  const afterNominalMetrics = await dbClient.getPruningMetrics();
  assert(
    afterNominalMetrics.nominalTracesPruned > beforePruningMetrics.nominalTracesPruned,
    'Nominal trace count incremented without storing trace body in database'
  );
  assert(
    afterNominalMetrics.storageSavedPct >= 90.0,
    `Zero-waste storage saved: ${afterNominalMetrics.storageSavedPct}% (expected >= 90%)`
  );

  const afterNominalAnomCount = (await dbClient.getAnomalousIncidents(100)).length;
  assert(
    afterNominalAnomCount === initialAnomCount,
    'Nominal trace was pruned immediately and NOT inserted into anomalous_microservices'
  );

  // Test 4: Abnormal Microservice Persistence when exceeding threshold tau
  console.log('\n--- 4. Abnormal Microservice Persistence (Exceeding tau) ---');
  const testIncidentId = `test_inc_${Date.now()}`;
  const mockAnomalyRecord = {
    id: `anom_test_${Date.now()}`,
    incident_id: testIncidentId,
    timestamp: Date.now(),
    root_cause_service_id: 'db-cluster',
    symptom_service_id: 'api-gateway',
    anomaly_score: 0.94,
    threshold_tau: initialTau.tau,
    reconstruction_error: 2.15,
    propagation_path: ['db-cluster', 'payment-service', 'order-service', 'checkout-service', 'api-gateway'],
    gnn_edge_attributions: [
      { source: 'payment-service', target: 'db-cluster', importance: 0.95, latencyMs: 1400, errorRate: 0.05 },
    ],
    gnn_feature_attributions: [
      { featureName: 'Latency', importance: 0.96, baselineVal: 28.5, currentVal: 1450.0 },
    ],
    evidence_log: [
      { type: 'temporal_onset', description: 'Early temporal inflection at db-cluster', confidenceContribution: 0.35 },
    ],
    resolved: false,
  };

  const mockSpans = [
    {
      span_id: `sp_test_root_${Date.now()}`,
      trace_id: `trace_test_${Date.now()}`,
      incident_id: testIncidentId,
      service_name: 'api-gateway',
      operation_name: 'POST /v2/checkout/place-order',
      duration_ms: 1420.0,
      status_code: 504,
      error_message: 'GatewayTimeout: upstream service took too long to respond',
      attributes: { 'http.status_code': 504 },
    },
    {
      span_id: `sp_test_db_${Date.now()}`,
      trace_id: `trace_test_${Date.now()}`,
      incident_id: testIncidentId,
      service_name: 'db-cluster',
      operation_name: 'SELECT pg_advisory_xact_lock(account_id) FOR UPDATE',
      duration_ms: 1350.0,
      status_code: 500,
      error_message: 'QueryExecutionTimeout: lock wait timeout exceeded',
      attributes: { 'db.system': 'postgresql' },
    },
  ];

  await dbClient.persistAnomalousIncident(mockAnomalyRecord, mockSpans);

  const incidentsFromDb = await dbClient.getAnomalousIncidents(10);
  const foundIncident = incidentsFromDb.find((i) => i.incident_id === testIncidentId);
  assert(foundIncident !== undefined, 'Abnormal incident successfully stored in anomalous_microservices table');
  assert(foundIncident?.root_cause_service_id === 'db-cluster', 'Root cause service ID stored correctly');
  assert(foundIncident?.anomaly_score === 0.94, 'Anomaly score stored correctly');
  assert(foundIncident?.threshold_tau === initialTau.tau, 'Dynamic threshold tau stored with incident');

  const spansFromDb = await dbClient.getAnomalousSpans(testIncidentId);
  assert(spansFromDb.length === 2, `Anomalous spans correctly persisted in anomalous_spans (${spansFromDb.length} spans)`);
  assert(spansFromDb.some((s) => s.service_name === 'db-cluster'), 'Database span persisted with query lock error');

  // Test 5: Incident Resolution Update in Database
  console.log('\n--- 5. Incident Resolution ---');
  await dbClient.resolveIncident(testIncidentId);
  const updatedIncidents = await dbClient.getAnomalousIncidents(10);
  const resolvedIncident = updatedIncidents.find((i) => i.incident_id === testIncidentId);
  assert(resolvedIncident?.resolved === true, 'Incident resolved state updated in database');

  // Test 6: ST-GNN Model Inference & GNNExplainer
  console.log('\n--- 6. ST-GNN Model Forward Pass & Explainability ---');
  const snap = telemetryStore.tick();
  assert(snap.nodes.length >= 10, 'Graph contains all service nodes');
  const forwardRes = stGnnModel.forward(snap.nodes, snap.edges);
  assert(Object.keys(forwardRes.anomalyScores).length === snap.nodes.length, 'ST-GNN computes scores for all nodes');
  assert(Object.keys(forwardRes.reconstructionErrors).length === snap.nodes.length, 'ST-GNN computes reconstruction errors');

  // Test 7: Fault Injection & Automated Root Cause Analysis
  console.log('\n--- 7. Chaos Injection & Evidence-Based RCA ---');
  telemetryStore.triggerFault('latency_spike', 'db-cluster', 10, 4.0);
  const faultedSnapshot = telemetryStore.tick();
  assert(faultedSnapshot.anomalyDetected === true, 'Faulted snapshot triggered anomaly detection');

  const explainerRes = stGnnModel.explain('db-cluster', faultedSnapshot.nodes, faultedSnapshot.edges);
  assert(explainerRes.edgeAttributions.length > 0, 'GNNExplainer produced continuous edge attribution mask');

  const rcaReport = rcaEngine.analyzeRootCause(
    'checkout-service',
    faultedSnapshot.nodes,
    faultedSnapshot.edges,
    faultedSnapshot.traces,
    explainerRes.edgeAttributions,
    explainerRes.featureAttributions,
    'latency_spike'
  );
  assert(rcaReport.rootCauseCandidate === 'db-cluster', 'Evidence-based RCA successfully isolated db-cluster as root cause');
  assert(rcaReport.propagationPath.length >= 2, 'RCA reconstructed multi-node propagation cascade path');

  // Clean up faults
  telemetryStore.clearAllFaults();
  const resetSnap = telemetryStore.tick();
  assert(resetSnap.activeFaults.length === 0, 'All chaos faults successfully cleared');

  console.log('\n===============================================================');
  console.log('  ALL AUTOMATED TESTS PASSED SUCCESSFULLY (7/7)');
  console.log('===============================================================');
}

runTestSuite().catch((err) => {
  console.error('Test suite failed:', err);
  process.exit(1);
});
