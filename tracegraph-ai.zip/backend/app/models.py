import uuid
from datetime import datetime
from sqlalchemy import Column, String, Float, Boolean, DateTime, ForeignKey, JSON, Integer, BigInteger, Text
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class Service(Base):
    __tablename__ = "services"

    id = Column(String(128), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False, index=True)
    tier = Column(String(64), nullable=False, default="business") # edge, core, business, data, cache, etc.
    host = Column(String(255), nullable=False, default="localhost")
    version = Column(String(64), nullable=False, default="v1.0.0")
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    baseline_stats = relationship("BaselineStat", back_populates="service", cascade="all, delete-orphan")
    anomalies_as_root = relationship("AnomalousMicroservice", foreign_keys="[AnomalousMicroservice.root_cause_service_id]", back_populates="root_cause_service")
    anomalies_as_symptom = relationship("AnomalousMicroservice", foreign_keys="[AnomalousMicroservice.symptom_service_id]", back_populates="symptom_service")


class BaselineStat(Base):
    __tablename__ = "baseline_stats"

    service_id = Column(String(128), ForeignKey("services.id", ondelete="CASCADE"), primary_key=True)
    metric_name = Column(String(128), primary_key=True) # latency_ms, error_rate, reconstruction_mse
    mean_val = Column(Float, nullable=False, default=0.0) # mu_0 (Baseline rolling mean)
    std_val = Column(Float, nullable=False, default=0.0) # sigma_0 (Baseline rolling std)
    sample_count = Column(Integer, nullable=False, default=0)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    service = relationship("Service", back_populates="baseline_stats")


class AnomalousMicroservice(Base):
    """
    Zero-Waste Storage Strategy:
    Stores ONLY microservices that exceed dynamic threshold tau = mu_baseline + k * sigma_baseline
    Nominal microservice traces are pruned immediately.
    """
    __tablename__ = "anomalous_microservices"

    id = Column(String(128), primary_key=True, default=lambda: str(uuid.uuid4()))
    incident_id = Column(String(128), nullable=False, index=True)
    timestamp = Column(BigInteger, nullable=False, index=True)
    root_cause_service_id = Column(String(128), ForeignKey("services.id", ondelete="CASCADE"), nullable=False, index=True)
    symptom_service_id = Column(String(128), ForeignKey("services.id", ondelete="CASCADE"), nullable=False, index=True)
    anomaly_score = Column(Float, nullable=False, default=0.0) # tau_i
    threshold_tau = Column(Float, nullable=False, default=0.0) # tau
    reconstruction_error = Column(Float, nullable=False, default=0.0)
    propagation_path = Column(JSON, nullable=False, default=list) # Ordered array of cascaded nodes
    gnn_edge_attributions = Column(JSON, nullable=False, default=list) # GNNExplainer continuous edge masks M_e
    gnn_feature_attributions = Column(JSON, nullable=False, default=list) # GNNExplainer feature importance masks M_f
    evidence_log = Column(JSON, nullable=False, default=list)
    resolved = Column(Boolean, nullable=False, default=False)

    root_cause_service = relationship("Service", foreign_keys=[root_cause_service_id], back_populates="anomalies_as_root")
    symptom_service = relationship("Service", foreign_keys=[symptom_service_id], back_populates="anomalies_as_symptom")
    spans = relationship("AnomalousSpan", back_populates="incident", cascade="all, delete-orphan", primaryjoin="AnomalousMicroservice.incident_id==foreign(AnomalousSpan.incident_id)")


class AnomalousSpan(Base):
    __tablename__ = "anomalous_spans"

    span_id = Column(String(128), primary_key=True)
    trace_id = Column(String(128), nullable=False, index=True)
    incident_id = Column(String(128), nullable=False, index=True)
    service_name = Column(String(255), nullable=False)
    operation_name = Column(String(255), nullable=False)
    duration_ms = Column(Float, nullable=False, default=0.0)
    status_code = Column(Integer, nullable=False, default=200)
    error_message = Column(Text, nullable=True)
    attributes = Column(JSON, nullable=False, default=dict)

    incident = relationship("AnomalousMicroservice", back_populates="spans", primaryjoin="AnomalousMicroservice.incident_id==foreign(AnomalousSpan.incident_id)")
