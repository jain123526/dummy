/**
 * TraceGraph AI — Standalone ML Model Evaluation Pipeline
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { stGnnModel } from '../src/engine/stGnnModel';
import { telemetryStore } from '../src/engine/telemetryStore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runEvaluation() {
  console.log('===============================================================');
  console.log('  TraceGraph AI — Standalone ML Model Evaluation Pipeline');
  console.log('===============================================================');

  const cwdPath = path.resolve(process.cwd(), 'ml/checkpoints/metrics.json');
  const relPath = path.resolve(__dirname, '../ml/checkpoints/metrics.json');
  const metricsPath = fs.existsSync(cwdPath) ? cwdPath : relPath;

  if (fs.existsSync(metricsPath)) {
    const data = JSON.parse(fs.readFileSync(metricsPath, 'utf-8'));
    console.log(`Model Checkpoint Version:  v2.1-prod-gatv2`);
    console.log(`Last Trained Timestamp:    ${data.trainedAt}`);
    console.log(`Evaluated Test Snapshots:  ${data.testSamples}`);
    console.log('---------------------------------------------------------------');
    console.log(`Accuracy:                  ${(data.accuracy * 100).toFixed(2)}%`);
    console.log(`Precision:                 ${(data.precision * 100).toFixed(2)}%`);
    console.log(`Recall:                    ${(data.recall * 100).toFixed(2)}%`);
    console.log(`F1-Score:                  ${(data.f1 * 100).toFixed(2)}%`);
    console.log(`AUROC:                     ${(data.auroc * 100).toFixed(2)}%`);
    console.log(`False Positive Rate (FPR): ${(data.falsePositiveRate * 100).toFixed(2)}%`);
    console.log(`RCA Top-1 Accuracy:        ${(data.rcaTop1 * 100).toFixed(2)}%`);
    console.log(`RCA Top-3 Accuracy:        ${(data.rcaTop3 * 100).toFixed(2)}%`);
    console.log(`Mean Forward Latency:      ${data.meanInferenceLatencyMs.toFixed(2)} ms`);
    console.log('===============================================================');
  } else {
    console.log('  No checkpoint found. Running quick live evaluation on snapshot buffer...');
    const snapshot = telemetryStore.tick();
    const { anomalyScores } = stGnnModel.forward(snapshot.nodes, snapshot.edges);
    console.log('Scores computed:', anomalyScores);
  }
}

runEvaluation().catch(console.error);
